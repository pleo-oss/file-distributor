## Purpose

This repository stores a series of files eg. GitHub Actions workflows that are common among many of the Pleo repositories.

## Supported file types

We support all types of files eg. json, yaml, text.

## Templates

We use Go templates with `[[[ ]]]` delimiters https://golang.org/pkg/text/template

## Conditional Configuration

Workflows currently support a number of optional configurations that enable additional functionality across all of our templates.

These are the existing possible `globalValues` options:

- `databaseMigrationEnabled`
- `deploymentEnabled`
- `funcTestEnabled`
- `productionDeploymentEnabled`
- `releaseOpenAPIClients`
- `stripeKeyRequired`
- `jdkVersion`
- `allowKodiakAutoMerge`
- `datadogTestLoggingEnabled`
- `redisRequired`
- `postgresRequired`
- `autoRelease`
- `appName`
- `defaultBranch`
- `appPort`
- `metricsPort`
- `autoApproveRenovatePrs`
- `doraMetricsReportingEnabled`
- `sendOpsLevelDeployNotifications`
- `sendOpsLevelVulnerabilityCheck`
- `postgresImageVersion`
- `redisImageVersion`
- `publishTypeScriptFrontendModels`

### Adding New Conditions

- Add your condition in the appropriate template ([example](https://github.com/pleo-io/centralized-templates/pull/88/files))
- Add a sensible default value [here](https://github.com/pleo-io/file-distributor/blob/a28aa9bbfad9c0ccd9f545a2d6675b0d0a08e7be/config/apps.yaml#L62)
- Reference this value under `globalValues` in your moon's config that lives in `file-distributor` ([example](https://github.com/pleo-io/file-distributor/pull/37/files))

## Example file

```
#test_file.txt

random text [[[ .appName ]]] with templated value

another line [[[ .templatedValue ]]] with template
```

Values `.appName` and `.templatedValue` need to be specified in https://github.com/pleo-io/file-distributor repository.

## Files structure

```
- templates
  - github
    - workflows
      - file1.yaml
      - file2.yaml
  - dockerfile
      - dockerfile1
      - dockerfile2
```

## Distribution

Files are distributed in https://github.com/pleo-io/file-distributor repository.

## Contributing

This repository is released using [auto](https://github.com/intuit/auto). A new version is released according to the PR labels and an updated `CHANGELOG.md` file will be automatically released whenever PR is merged to the `main` branch.

### Releasing

Make sure to name your PR and label your PR description according to the work contained in the PR.

#### Labels

- `major` Indicates a breaking change
- `minor` Indicates a feature
- `patch` Indicates a bug fix
- `internal` Indicates that these changes are internal to the library

#### Additional release notes

For additional release notes in `CHANGELOG.md`, add `##Release notes:` with additional notes underneath to your PR description.

#### Examples

<details>
<summary>Breaking change <code>1.X.X -> 2.X.X</code></summary>

- PR title:

  ```
  Remove <workflow>
  ```

- PR label:

  ```
  major
  ```

- PR description:

  ```
  Remove the workflow <workflow>

  ## Release notes:
  This breaks existing repositories which currently use this workflow. To mitigiate this do <mitigation>.
  ```

- **Result:** The version increments from `1.1.X` to `1.2.X`

</details>

<details>
<summary>Feature release <code>1.1.X -> 1.2.X</code></summary>

- PR title:

  ```
  Add <workflow>
  ```

- PR label:

  ```
  minor
  ```

- PR description:

  ```
  Added support for <feature> through new workflow <workflow>.

  ## Release notes:
  This adds <workflow>, which will <functionality>.
  ```

- **Result:** The version increments from `1.1.X` to `1.2.X`

</details>

<details>
<summary>Patch release <code>1.0.1 -> 1.0.2</code></summary>

- PR title:

  ```
  Fix <bug>
  ```

- PR label:

  ```
  patch
  ```

- PR description:

  ```
  Fixed a bug where <behaviour> in <workflow>.
  ```

- **Result:** The version increments from `1.0.1` to `1.0.2`

</details>

#### Deploying a version

Once your changes are approved and merged, a new version will be published to our package repository.

We use [`semantic-release`](https://github.com/semantic-release/semantic-release).

## `globalValues`


### `databaseMigrationEnabled`
`// TODO`

### `deploymentEnabled`
`// TODO`

### `funcTestEnabled`
`// TODO`

### `productionDeploymentEnabled`
This value controls whether you want to deploy to our production K8S cluster

### `releaseOpenAPIClients`
This value determines whether your service should release its generated OpenAPI clients. See also the `autoRelease` value below.

### `stripeKeyRequired`
`// TODO`

### `jdkVersion`
This value determines the JDK version of your service.

### `allowKodiakAutoMerge`
This will allow Kodiak to auto-update and auto-merge PRs in your repository once PRs are passing all checks using the `automerge` or `autoupdate` PR labels.

### `datadogTestLoggingEnabled`
When enabled, we send unit and functional test results to Datadog. See [documentation](https://docs.datadoghq.com/continuous_integration/setup_tests/java/?tab=onpremisesciproviderdatadogagent). Also see [dashboard for tests results in Datadog](https://app.datadoghq.eu/ci/test-services?view=branches).

### `redisRequired`
Provision a redis instance for tests to run against

### `postgresRequired`
Provision a postgres instance for tests to run against

### `autoApproveRenovatePrs`
This will make our Kodiak integration give Renovate PRs 1 auto-approval automatically.

### `autoRelease`
This value will auto-release your Kotlin service to our private package repository and generate an up-to-date `CHANGELOG`. Labels on PR determine the release type (either `major`, `minor`, `patch` or `internal`). This value depends on the [`incrementVersion` Gradle task](https://github.com/pleo-io/pluto/blob/main/build.gradle.kts#L133) to function correctly.

### `appName`
This value determines the name of your service.

### `defaultBranch`
This value determines the name of the default branch in the repository of your service (usually `main`, or `master` in older repositories).

### `appPort`
This value determines the default port for your service.

### `metricsPort`
This value determines the default metrics port for your service.

### `doraMetricsReportingEnabled`
Enable reporting workflow events (such as production deployments) to a serverless function. This data is then used to calculate various metrics such as Deployment Frequency, Mean Time to Change, Change Failure Rate & Mean Time to Repair

### `sendOpsLevelDeployNotifications`
When enabled, OpsLevel will be notified about production deploys.

### `sendOpsLevelVulnerabilityCheck`
When enabled, the result of a `snyk test` will be sent to OpsLevel.

### `postgresImageVersion`
Image version (full) for the postgres service when enabled (check [postgresRequired](#postgresrequired))

### `redisImageVersion`
Image version (full) for the redis service when enabled (check [redisRequired](#redisrequired))

### `publishTypeScriptFrontendModels`
Whether to publish generated TypeScript request/response types for frontend calls to generated OpenAPI clients.

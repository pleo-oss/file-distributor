# v10.7.1 (Tue Aug 30 2022)

### Release Notes

#### Update gradle/gradle-build-action action to v2.3.0 ([#460](https://github.com/pleo-io/centralized-templates/pull/460))

<details>
<summary>gradle/gradle-build-action</summary>

---

#### 🐞 Fixes

- Update gradle/gradle-build-action action to v2.3.0 [#460](https://github.com/pleo-io/centralized-templates/pull/460) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

#### Authors: 1

- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.7.0 (Thu Aug 25 2022)

#### 🎁 Features

- Speed up feature deploy build steps [#458](https://github.com/pleo-io/centralized-templates/pull/458) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### 🐞 Fixes

- Prefer known-good commenting Action [#457](https://github.com/pleo-io/centralized-templates/pull/457) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@dpotyralski](https://github.com/dpotyralski))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Damian Potyralski ([@dpotyralski](https://github.com/dpotyralski))

---

# v10.6.4 (Thu Aug 25 2022)

#### 🐞 Fixes

- Fix Snyk workflow and remove useless cache [#456](https://github.com/pleo-io/centralized-templates/pull/456) ([@jsfr](https://github.com/jsfr))

#### 🏠 Internal

- Fix template ownership [#454](https://github.com/pleo-io/centralized-templates/pull/454) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 3

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Jens Fredskov ([@jsfr](https://github.com/jsfr))

---

# v10.6.3 (Wed Aug 24 2022)

#### 🐞 Fixes

- Move env standardization to _after_ the code checkout [#455](https://github.com/pleo-io/centralized-templates/pull/455) ([@jsfr](https://github.com/jsfr))

#### 🏠 Internal

- chore(templates): update repository configuration from templates [#452](https://github.com/pleo-io/centralized-templates/pull/452) (dev@pleo.io [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor))

#### Authors: 3

- [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor)
- Jens Fredskov ([@jsfr](https://github.com/jsfr))
- pleo-io (dev@pleo.io)

---

# v10.6.2 (Tue Aug 23 2022)

#### 🐞 Fixes

- Skip build step in TS generation [#453](https://github.com/pleo-io/centralized-templates/pull/453) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v10.6.1 (Tue Aug 23 2022)

### Release Notes

#### chore(deps): update tj-actions/glob action to v11 ([#450](https://github.com/pleo-io/centralized-templates/pull/450))

<details>
<summary>tj-actions/glob</summary>

### [`v11.1`](https://togithub.com/tj-actions/glob/blob/HEAD/HISTORY.md#v111-httpsgithubcomtj-actionsglobtreev111-2022-08-22)

[Compare Source](https://togithub.com/tj-actions/glob/compare/v9.2...v11.1)

[Full Changelog](https://togithub.com/tj-actions/glob/compare/v11...v11.1)

**Merged pull requests:**

-   Upgraded to v11 [#&#8203;344](https://togithub.com/tj-actions/glob/pull/344) ([jackton1](https://togithub.com/jackton1))
-   Update typescript-eslint monorepo to v5.34.0 [#&#8203;343](https://togithub.com/tj-actions/glob/pull/343) ([renovate\[bot\]](https://togithub.com/apps/renovate))

</details>

---

---

#### 🐞 Fixes

- chore(deps): update tj-actions/glob action to v11 [#450](https://github.com/pleo-io/centralized-templates/pull/450) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.6.0 (Tue Aug 23 2022)

#### 🎁 Features

- Avoid over-assigning reviewers in case of broken assignment Action [#451](https://github.com/pleo-io/centralized-templates/pull/451) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### 🏠 Internal

- fix opslevel dependencies [#449](https://github.com/pleo-io/centralized-templates/pull/449) ([@steffkes](https://github.com/steffkes))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Stefan ([@steffkes](https://github.com/steffkes))

---

# v10.5.0 (Fri Aug 19 2022)

#### 🎁 Features

- Cache Auto with versioning and Renovate support [#448](https://github.com/pleo-io/centralized-templates/pull/448) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### 🏠 Internal

- chore(templates): update repository configuration from templates [#446](https://github.com/pleo-io/centralized-templates/pull/446) (dev@pleo.io [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor))

#### Authors: 4

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor)
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- pleo-io (dev@pleo.io)

---

# v10.4.1 (Thu Aug 18 2022)

#### 🐞 Fixes

- Add missing condition to release workflow [#447](https://github.com/pleo-io/centralized-templates/pull/447) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### ⚠️ Pushed to `main`

- Add missing attribute to README ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v10.4.0 (Thu Aug 18 2022)

#### 🎁 Features

- Add configuration for publishing TypeScript frontend models [#445](https://github.com/pleo-io/centralized-templates/pull/445) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### 🏠 Internal

- Update contribution part of readme [#443](https://github.com/pleo-io/centralized-templates/pull/443) ([@jsfr](https://github.com/jsfr))

#### Authors: 3

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Jens Fredskov ([@jsfr](https://github.com/jsfr))

---

# v10.3.1 (Thu Aug 18 2022)

### Release Notes

#### Update shioyang/check-pr-labels-on-push-action action to v1.0.4 ([#440](https://github.com/pleo-io/centralized-templates/pull/440))

<details>
<summary>shioyang/check-pr-labels-on-push-action</summary>

#### Update aws-actions/configure-aws-credentials action to v1.7.0 ([#442](https://github.com/pleo-io/centralized-templates/pull/442))

<details>
<summary>aws-actions/configure-aws-credentials</summary>

---

#### 🐞 Fixes

- Update shioyang/check-pr-labels-on-push-action action to v1.0.4 [#440](https://github.com/pleo-io/centralized-templates/pull/440) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))
- Allow TS model publishing to fail [#444](https://github.com/pleo-io/centralized-templates/pull/444) ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Update aws-actions/configure-aws-credentials action to v1.7.0 [#442](https://github.com/pleo-io/centralized-templates/pull/442) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 3

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.3.0 (Thu Aug 18 2022)

#### 🎁 Features

- Fix snyk workflow [#439](https://github.com/pleo-io/centralized-templates/pull/439) ([@jsfr](https://github.com/jsfr))

#### Authors: 1

- Jens Fredskov ([@jsfr](https://github.com/jsfr))

---

# v10.2.7 (Thu Aug 18 2022)

### Release Notes

#### Update aws-actions/amazon-ecr-login action to v1.5.1 ([#441](https://github.com/pleo-io/centralized-templates/pull/441))

<details>
<summary>aws-actions/amazon-ecr-login</summary>

---

#### 🐞 Fixes

- Update aws-actions/amazon-ecr-login action to v1.5.1 [#441](https://github.com/pleo-io/centralized-templates/pull/441) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.6 (Thu Aug 18 2022)

#### 🐞 Fixes

- Skip Kotlin Buildx cache setup unless on the default branch [#438](https://github.com/pleo-io/centralized-templates/pull/438) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v10.2.5 (Wed Aug 17 2022)

#### 🐞 Fixes

- Update mikepenz/action-junit-report action to v3 [#428](https://github.com/pleo-io/centralized-templates/pull/428) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

#### Authors: 1

- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.4 (Tue Aug 16 2022)

### Release Notes

#### Update actions/checkout action to v3 ([#424](https://github.com/pleo-io/centralized-templates/pull/424))

<details>
<summary>actions/checkout</summary>

### [`v3.0.2`](https://togithub.com/actions/checkout/blob/HEAD/CHANGELOG.md#v302)

[Compare Source](https://togithub.com/actions/checkout/compare/v3.0.1...v3.0.2)

-   [Add input `set-safe-directory`](https://togithub.com/actions/checkout/pull/770)

### [`v3.0.1`](https://togithub.com/actions/checkout/blob/HEAD/CHANGELOG.md#v301)

[Compare Source](https://togithub.com/actions/checkout/compare/v3.0.0...v3.0.1)

-   [Fixed an issue where checkout failed to run in container jobs due to the new git setting `safe.directory`](https://togithub.com/actions/checkout/pull/762)
-   [Bumped various npm package versions](https://togithub.com/actions/checkout/pull/744)

### [`v3.0.0`](https://togithub.com/actions/checkout/blob/HEAD/CHANGELOG.md#v300)

[Compare Source](https://togithub.com/actions/checkout/compare/v2.4.2...v3.0.0)

-   [Update to node 16](https://togithub.com/actions/checkout/pull/689)

#### Update tj-actions/changed-files action to v26 ([#437](https://github.com/pleo-io/centralized-templates/pull/437))

<details>
<summary>tj-actions/changed-files</summary>

### [`v26.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v261-httpsgithubcomtj-actionschanged-filestreev261-2022-08-15)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v24.1...v26.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v26...v26.1)

**Merged pull requests:**

-   fix: error retrieving base sha. [#&#8203;579](https://togithub.com/tj-actions/changed-files/pull/579) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v26 [#&#8203;577](https://togithub.com/tj-actions/changed-files/pull/577) ([jackton1](https://togithub.com/jackton1))

</details>

---

---

#### 🐞 Fixes

- Update actions/checkout action to v3 [#424](https://github.com/pleo-io/centralized-templates/pull/424) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))
- Update tj-actions/changed-files action to v26 [#437](https://github.com/pleo-io/centralized-templates/pull/437) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@andersfischernielsen](https://github.com/andersfischernielsen))

#### 🏠 Internal

- Create opslevel.yml [#436](https://github.com/pleo-io/centralized-templates/pull/436) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.3 (Mon Aug 15 2022)

#### 🐞 Fixes

- Update redis Docker tag to v7 [#430](https://github.com/pleo-io/centralized-templates/pull/430) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@dacloutier](https://github.com/dacloutier))

#### Authors: 2

- David Cloutier ([@dacloutier](https://github.com/dacloutier))
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.2 (Mon Aug 15 2022)

#### 🐞 Fixes

- Update actions/upload-artifact action to v3 [#426](https://github.com/pleo-io/centralized-templates/pull/426) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@dpotyralski](https://github.com/dpotyralski) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 3

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Damian Potyralski ([@dpotyralski](https://github.com/dpotyralski))
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.1 (Fri Aug 12 2022)

### Release Notes

#### Update actions/setup-node action to v3 ([#425](https://github.com/pleo-io/centralized-templates/pull/425))

<details>
<summary>actions/setup-node</summary>

---

#### 🐞 Fixes

- Update actions/setup-node action to v3 [#425](https://github.com/pleo-io/centralized-templates/pull/425) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.2.0 (Thu Aug 11 2022)

#### 🎁 Features

- Add concurrency and previous run cancellation to workflows [#435](https://github.com/pleo-io/centralized-templates/pull/435) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v10.1.7 (Thu Aug 11 2022)

### Release Notes

#### Update pleo-io/actions action to v16 ([#429](https://github.com/pleo-io/centralized-templates/pull/429))

<details>
<summary>pleo-io/actions</summary>

---

#### 🐞 Fixes

- Update pleo-io/actions action to v16 [#429](https://github.com/pleo-io/centralized-templates/pull/429) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.1.6 (Thu Aug 11 2022)

### Release Notes

#### Update tj-actions/changed-files action to v24 ([#431](https://github.com/pleo-io/centralized-templates/pull/431))

<details>
<summary>tj-actions/changed-files</summary>

### [`v24.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v241-httpsgithubcomtj-actionschanged-filestreev241-2022-08-03)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v23.2...v24.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v24...v24.1)

**Implemented enhancements:**

-   \[Feature] Execute against master [#&#8203;556](https://togithub.com/tj-actions/changed-files/issues/556)
-   \[Feature]  implement an outputs for matrix compatible jobs [#&#8203;530](https://togithub.com/tj-actions/changed-files/issues/530)

**Fixed bugs:**

-   \[BUG] Separator removing double-quotes [#&#8203;545](https://togithub.com/tj-actions/changed-files/issues/545)

**Merged pull requests:**

-   fix: bug with matrix job [#&#8203;560](https://togithub.com/tj-actions/changed-files/pull/560) ([jackton1](https://togithub.com/jackton1))
-   fix: bug with matrix job [#&#8203;559](https://togithub.com/tj-actions/changed-files/pull/559) ([jackton1](https://togithub.com/jackton1))
-   chore: update action name [#&#8203;558](https://togithub.com/tj-actions/changed-files/pull/558) ([jackton1](https://togithub.com/jackton1))
-   feat: add support for json formatted output. [#&#8203;557](https://togithub.com/tj-actions/changed-files/pull/557) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v24 [#&#8203;555](https://togithub.com/tj-actions/changed-files/pull/555) ([jackton1](https://togithub.com/jackton1))

### [`v23.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v232-httpsgithubcomtj-actionschanged-filestreev232-2022-07-18)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v23.1...v23.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v23.1...v23.2)

**Fixed bugs:**

-   \[BUG] Repo name changed, workflows are broken [#&#8203;542](https://togithub.com/tj-actions/changed-files/issues/542)

**Closed issues:**

-   Dependency Dashboard [#&#8203;27](https://togithub.com/tj-actions/changed-files/issues/27)

**Merged pull requests:**

-   feat: fix bug with similar commit hashes. [#&#8203;549](https://togithub.com/tj-actions/changed-files/pull/549) ([jackton1](https://togithub.com/jackton1))
-   chore: update readme [#&#8203;544](https://togithub.com/tj-actions/changed-files/pull/544) ([jackton1](https://togithub.com/jackton1))
-   chore(deps): update tj-actions/github-changelog-generator action to v1.14 [#&#8203;541](https://togithub.com/tj-actions/changed-files/pull/541) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Updated README.md [#&#8203;540](https://togithub.com/tj-actions/changed-files/pull/540) ([jackton1](https://togithub.com/jackton1))
-   chore: update test [#&#8203;539](https://togithub.com/tj-actions/changed-files/pull/539) ([jackton1](https://togithub.com/jackton1))
-   chore: update README.md [#&#8203;538](https://togithub.com/tj-actions/changed-files/pull/538) ([jackton1](https://togithub.com/jackton1))
-   docs: add JoeOvo as a contributor for doc [#&#8203;537](https://togithub.com/tj-actions/changed-files/pull/537) ([allcontributors\[bot\]](https://togithub.com/apps/allcontributors))
-   Update README.md [#&#8203;536](https://togithub.com/tj-actions/changed-files/pull/536) ([JoeOvo](https://togithub.com/JoeOvo))
-   Upgraded to v23.1 [#&#8203;535](https://togithub.com/tj-actions/changed-files/pull/535) ([jackton1](https://togithub.com/jackton1))

### [`v23.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v231-httpsgithubcomtj-actionschanged-filestreev231-2022-06-24)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v22.2...v23.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v23...v23.1)

**Fixed bugs:**

-   \[BUG] Misleading error if git command is missing [#&#8203;532](https://togithub.com/tj-actions/changed-files/issues/532)

**Merged pull requests:**

-   chore: removed unused code [#&#8203;534](https://togithub.com/tj-actions/changed-files/pull/534) ([jackton1](https://togithub.com/jackton1))
-   chore: improve error handling [#&#8203;533](https://togithub.com/tj-actions/changed-files/pull/533) ([jackton1](https://togithub.com/jackton1))
-   chore(deps): update tj-actions/verify-changed-files action to v10 [#&#8203;531](https://togithub.com/tj-actions/changed-files/pull/531) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Updated README.md [#&#8203;528](https://togithub.com/tj-actions/changed-files/pull/528) ([jackton1](https://togithub.com/jackton1))
-   chore(deps): update codacy/codacy-analysis-cli-action action to v4.1.0 [#&#8203;527](https://togithub.com/tj-actions/changed-files/pull/527) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   docs: add deronnax as a contributor for doc [#&#8203;526](https://togithub.com/tj-actions/changed-files/pull/526) ([allcontributors\[bot\]](https://togithub.com/apps/allcontributors))
-   fix mispellings [#&#8203;525](https://togithub.com/tj-actions/changed-files/pull/525) ([deronnax](https://togithub.com/deronnax))
-   chore: reformat manual-test.yml [#&#8203;524](https://togithub.com/tj-actions/changed-files/pull/524) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v23 [#&#8203;523](https://togithub.com/tj-actions/changed-files/pull/523) ([jackton1](https://togithub.com/jackton1))

### [`v22.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v222-httpsgithubcomtj-actionschanged-filestreev222-2022-06-02)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v22.1...v22.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v22.1...v22.2)

**Fixed bugs:**

-   \[BUG] "Unable to locate the current sha" when using ` use_fork_point  ` [#&#8203;506](https://togithub.com/tj-actions/changed-files/issues/506)

**Merged pull requests:**

-   Updated README.md [#&#8203;516](https://togithub.com/tj-actions/changed-files/pull/516) ([jackton1](https://togithub.com/jackton1))
-   feat: add support for configuring diff.relative [#&#8203;515](https://togithub.com/tj-actions/changed-files/pull/515) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v22.1 [#&#8203;514](https://togithub.com/tj-actions/changed-files/pull/514) ([jackton1](https://togithub.com/jackton1))

### [`v22.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v221-httpsgithubcomtj-actionschanged-filestreev221-2022-05-31)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v20.2...v22.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v22...v22.1)

**Merged pull requests:**

-   chore: upgrade tj-actions/glob from v9 to v9.2 [#&#8203;513](https://togithub.com/tj-actions/changed-files/pull/513) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v22 [#&#8203;512](https://togithub.com/tj-actions/changed-files/pull/512) ([jackton1](https://togithub.com/jackton1))

### [`v20.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v202-httpsgithubcomtj-actionschanged-filestreev202-2022-05-24)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v20.1...v20.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v20.1...v20.2)

**Fixed bugs:**

-   \[BUG] all_old_new_renamed_files is empty when providing a glob pattern. [#&#8203;467](https://togithub.com/tj-actions/changed-files/issues/467)

**Merged pull requests:**

-   fix: matching renamed files with glob patterns [#&#8203;498](https://togithub.com/tj-actions/changed-files/pull/498) ([jackton1](https://togithub.com/jackton1))
-   chore: Improve test coverage [#&#8203;497](https://togithub.com/tj-actions/changed-files/pull/497) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v20.1 [#&#8203;496](https://togithub.com/tj-actions/changed-files/pull/496) ([jackton1](https://togithub.com/jackton1))

### [`v20.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v201-httpsgithubcomtj-actionschanged-filestreev201-2022-05-22)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v19.3...v20.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v20...v20.1)

**Fixed bugs:**

-   \[BUG] Glob pattern doesn't work for markdown files  [#&#8203;492](https://togithub.com/tj-actions/changed-files/issues/492)
-   \[BUG] Using the fork point to detect file changes. [#&#8203;355](https://togithub.com/tj-actions/changed-files/issues/355)

**Merged pull requests:**

-   chore: test rename [#&#8203;495](https://togithub.com/tj-actions/changed-files/pull/495) ([jackton1](https://togithub.com/jackton1))
-   chore: Update README.md [#&#8203;494](https://togithub.com/tj-actions/changed-files/pull/494) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v20 [#&#8203;491](https://togithub.com/tj-actions/changed-files/pull/491) ([jackton1](https://togithub.com/jackton1))

### [`v19.3`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v193-httpsgithubcomtj-actionschanged-filestreev193-2022-05-14)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v19.2...v19.3)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v19.2...v19.3)

**Merged pull requests:**

-   fix: bug with renames [#&#8203;488](https://togithub.com/tj-actions/changed-files/pull/488) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v19.2 [#&#8203;487](https://togithub.com/tj-actions/changed-files/pull/487) ([jackton1](https://togithub.com/jackton1))

### [`v19.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v192-httpsgithubcomtj-actionschanged-filestreev192-2022-05-14)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v19.1...v19.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v19.1...v19.2)

**Merged pull requests:**

-   feat/add support for retrieving old and new names of renamed files [#&#8203;486](https://togithub.com/tj-actions/changed-files/pull/486) ([jackton1](https://togithub.com/jackton1))
-   Revert "feat: Added support for returning old and new names of renamed files" [#&#8203;485](https://togithub.com/tj-actions/changed-files/pull/485) ([jackton1](https://togithub.com/jackton1))
-   Updated README.md [#&#8203;484](https://togithub.com/tj-actions/changed-files/pull/484) ([jackton1](https://togithub.com/jackton1))
-   feat: Added support for returning old and new names of renamed files [#&#8203;483](https://togithub.com/tj-actions/changed-files/pull/483) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v19.1 [#&#8203;482](https://togithub.com/tj-actions/changed-files/pull/482) ([jackton1](https://togithub.com/jackton1))

### [`v19.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v191-httpsgithubcomtj-actionschanged-filestreev191-2022-05-14)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.7...v19.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v19...v19.1)

**Fixed bugs:**

-   \[BUG] Glob pattern for markdown files doesn't work properly [#&#8203;479](https://togithub.com/tj-actions/changed-files/issues/479)
-   \[BUG] Fails in Self-Hosted Runner [#&#8203;477](https://togithub.com/tj-actions/changed-files/issues/477)
-   \[BUG] File names with non ascii characters results in octal escape sequence output [#&#8203;437](https://togithub.com/tj-actions/changed-files/issues/437)

**Merged pull requests:**

-   chore(deps): update tj-actions/glob action to v7.20 [#&#8203;481](https://togithub.com/tj-actions/changed-files/pull/481) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update tj-actions/glob action to v7.18 [#&#8203;480](https://togithub.com/tj-actions/changed-files/pull/480) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update pascalgn/automerge-action action to v0.15.3 [#&#8203;478](https://togithub.com/tj-actions/changed-files/pull/478) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update peter-evans/create-pull-request action to v4.0.3 [#&#8203;476](https://togithub.com/tj-actions/changed-files/pull/476) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update tj-actions/glob action to v7.17 [#&#8203;475](https://togithub.com/tj-actions/changed-files/pull/475) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v19 [#&#8203;474](https://togithub.com/tj-actions/changed-files/pull/474) ([jackton1](https://togithub.com/jackton1))

### [`v18.7`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v187-httpsgithubcomtj-actionschanged-filestreev187-2022-04-08)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.6...v18.7)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.6...v18.7)

**Fixed bugs:**

-   \[BUG] Modified files treated as `Non Matching modified files` [#&#8203;450](https://togithub.com/tj-actions/changed-files/issues/450)

**Merged pull requests:**

-   chore(deps): update peter-evans/create-pull-request action to v4.0.1 [#&#8203;461](https://togithub.com/tj-actions/changed-files/pull/461) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v18.6 [#&#8203;460](https://togithub.com/tj-actions/changed-files/pull/460) ([jackton1](https://togithub.com/jackton1))

### [`v18.6`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v186-httpsgithubcomtj-actionschanged-filestreev186-2022-03-30)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.5...v18.6)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.5...v18.6)

**Fixed bugs:**

-   \[BUG] Intermittent "Unable to locate the current sha" [#&#8203;458](https://togithub.com/tj-actions/changed-files/issues/458)

**Merged pull requests:**

-   fix: resolved error with escaping unicode unsafe characters [#&#8203;459](https://togithub.com/tj-actions/changed-files/pull/459) ([jackton1](https://togithub.com/jackton1))
-   chore: remove unused code [#&#8203;457](https://togithub.com/tj-actions/changed-files/pull/457) ([jackton1](https://togithub.com/jackton1))
-   chore: test changes to .github workflows files [#&#8203;456](https://togithub.com/tj-actions/changed-files/pull/456) ([jackton1](https://togithub.com/jackton1))
-   chore: test filenames that should be escaped [#&#8203;455](https://togithub.com/tj-actions/changed-files/pull/455) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v18.5 [#&#8203;454](https://togithub.com/tj-actions/changed-files/pull/454) ([jackton1](https://togithub.com/jackton1))

### [`v18.5`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v185-httpsgithubcomtj-actionschanged-filestreev185-2022-03-29)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.4...v18.5)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.4...v18.5)

**Implemented enhancements:**

-   \[Feature] Get changes from all commits from a single push [#&#8203;447](https://togithub.com/tj-actions/changed-files/issues/447)

**Fixed bugs:**

-   \[BUG] Not able to compare current commit with the specific commit of a branch(in the Pull request event) [#&#8203;441](https://togithub.com/tj-actions/changed-files/issues/441)

**Merged pull requests:**

-   fix: bug passing invalid patterns to grep [#&#8203;453](https://togithub.com/tj-actions/changed-files/pull/453) ([jackton1](https://togithub.com/jackton1))
-   chore(deps): update tj-actions/glob action to v7.12 [#&#8203;451](https://togithub.com/tj-actions/changed-files/pull/451) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update pascalgn/automerge-action action to v0.15.2 [#&#8203;449](https://togithub.com/tj-actions/changed-files/pull/449) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update pascalgn/automerge-action action to v0.14.4 [#&#8203;448](https://togithub.com/tj-actions/changed-files/pull/448) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update peter-evans/create-pull-request action to v4 [#&#8203;446](https://togithub.com/tj-actions/changed-files/pull/446) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update tj-actions/glob action to v7.11 [#&#8203;445](https://togithub.com/tj-actions/changed-files/pull/445) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Updated README.md [#&#8203;444](https://togithub.com/tj-actions/changed-files/pull/444) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v18.4 [#&#8203;443](https://togithub.com/tj-actions/changed-files/pull/443) ([jackton1](https://togithub.com/jackton1))

### [`v18.4`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v184-httpsgithubcomtj-actionschanged-filestreev184-2022-03-21)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.3...v18.4)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.3...v18.4)

**Merged pull requests:**

-   Bump tj-actions/remark from 2.3 to 3 [#&#8203;442](https://togithub.com/tj-actions/changed-files/pull/442) ([dependabot\[bot\]](https://togithub.com/apps/dependabot))
-   chore(deps): update tj-actions/glob action to v7.10 [#&#8203;440](https://togithub.com/tj-actions/changed-files/pull/440) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Update README.md [#&#8203;439](https://togithub.com/tj-actions/changed-files/pull/439) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v18.3 [#&#8203;438](https://togithub.com/tj-actions/changed-files/pull/438) ([jackton1](https://togithub.com/jackton1))

### [`v18.3`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v183-httpsgithubcomtj-actionschanged-filestreev183-2022-03-16)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.2...v18.3)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.2...v18.3)

**Merged pull requests:**

-   chore(deps): update tj-actions/glob action to v7.9 [#&#8203;436](https://togithub.com/tj-actions/changed-files/pull/436) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v18.2 [#&#8203;435](https://togithub.com/tj-actions/changed-files/pull/435) ([jackton1](https://togithub.com/jackton1))

### [`v18.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v182-httpsgithubcomtj-actionschanged-filestreev182-2022-03-16)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v18.1...v18.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18.1...v18.2)

**Fixed bugs:**

-   \[BUG] Glob Pattern Incorrect? [#&#8203;433](https://togithub.com/tj-actions/changed-files/issues/433)
-   \[BUG] Providing files_ignore without using files input doesn't exclude ignored files [#&#8203;429](https://togithub.com/tj-actions/changed-files/issues/429)

**Merged pull requests:**

-   fix: bug omitting the fetch-depth for push based events [#&#8203;434](https://togithub.com/tj-actions/changed-files/pull/434) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v18.1 [#&#8203;432](https://togithub.com/tj-actions/changed-files/pull/432) ([jackton1](https://togithub.com/jackton1))

### [`v18.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v181-httpsgithubcomtj-actionschanged-filestreev181-2022-03-14)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v17.3...v18.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v18...v18.1)

**Merged pull requests:**

-   fix: bug providing files_ignore without files input [#&#8203;431](https://togithub.com/tj-actions/changed-files/pull/431) ([jackton1](https://togithub.com/jackton1))
-   chore(deps): update tj-actions/glob action to v7.7 [#&#8203;430](https://togithub.com/tj-actions/changed-files/pull/430) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update tj-actions/glob action to v7.6 [#&#8203;428](https://togithub.com/tj-actions/changed-files/pull/428) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore(deps): update tj-actions/github-changelog-generator action to v1.13 [#&#8203;427](https://togithub.com/tj-actions/changed-files/pull/427) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v18 [#&#8203;426](https://togithub.com/tj-actions/changed-files/pull/426) ([jackton1](https://togithub.com/jackton1))

### [`v17.3`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v173-httpsgithubcomtj-actionschanged-filestreev173-2022-03-08)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v17.2...v17.3)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v17.2...v17.3)

**Fixed bugs:**

-   \[BUG] Argument too long [#&#8203;419](https://togithub.com/tj-actions/changed-files/issues/419)
-   failed to  Get list of files on pull request merge [#&#8203;414](https://togithub.com/tj-actions/changed-files/issues/414)
-   \[BUG] Get all modified/deleted/added files from a Pull Request [#&#8203;410](https://togithub.com/tj-actions/changed-files/issues/410)

**Closed issues:**

-   \[BUG] Unexpected result [#&#8203;412](https://togithub.com/tj-actions/changed-files/issues/412)

**Merged pull requests:**

-   fix: bug using newline separator [#&#8203;418](https://togithub.com/tj-actions/changed-files/pull/418) ([jackton1](https://togithub.com/jackton1))
-   Revert "chore: test pull_requests events" [#&#8203;416](https://togithub.com/tj-actions/changed-files/pull/416) ([jackton1](https://togithub.com/jackton1))
-   chore: test pull_requests events [#&#8203;415](https://togithub.com/tj-actions/changed-files/pull/415) ([jackton1](https://togithub.com/jackton1))
-   Update codacy/codacy-analysis-cli-action action to v4.0.1 [#&#8203;413](https://togithub.com/tj-actions/changed-files/pull/413) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Update actions/checkout action [#&#8203;411](https://togithub.com/tj-actions/changed-files/pull/411) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Update peter-evans/create-pull-request action to v3.14.0 [#&#8203;409](https://togithub.com/tj-actions/changed-files/pull/409) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Update peter-evans/create-pull-request action to v3.13.0 [#&#8203;408](https://togithub.com/tj-actions/changed-files/pull/408) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v17.2 [#&#8203;407](https://togithub.com/tj-actions/changed-files/pull/407) ([jackton1](https://togithub.com/jackton1))

### [`v17.2`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v172-httpsgithubcomtj-actionschanged-filestreev172-2022-02-27)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v17.1...v17.2)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v17.1...v17.2)

**Fixed bugs:**

-   \[BUG] Gracefully handle errors for repositories without any previous commits [#&#8203;365](https://togithub.com/tj-actions/changed-files/issues/365)

**Merged pull requests:**

-   fix: bug detecting other deleted and modified [#&#8203;406](https://togithub.com/tj-actions/changed-files/pull/406) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v17.1 [#&#8203;405](https://togithub.com/tj-actions/changed-files/pull/405) ([jackton1](https://togithub.com/jackton1))

### [`v17.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v171-httpsgithubcomtj-actionschanged-filestreev171-2022-02-26)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v15.1...v17.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v17...v17.1)

**Closed issues:**

-   How can I set the action to review all commits since the last workflow run? [#&#8203;400](https://togithub.com/tj-actions/changed-files/issues/400)

**Merged pull requests:**

-   fix: handle errors for repositories without any previous commit history [#&#8203;404](https://togithub.com/tj-actions/changed-files/pull/404) ([jackton1](https://togithub.com/jackton1))
-   Updated submodule [#&#8203;403](https://togithub.com/tj-actions/changed-files/pull/403) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/github-changelog-generator action to v1.12 [#&#8203;402](https://togithub.com/tj-actions/changed-files/pull/402) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   chore: switch sed for awk [#&#8203;401](https://togithub.com/tj-actions/changed-files/pull/401) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v17 [#&#8203;399](https://togithub.com/tj-actions/changed-files/pull/399) ([jackton1](https://togithub.com/jackton1))

### [`v15.1`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v151-httpsgithubcomtj-actionschanged-filestreev151-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.7...v15.1)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v1.0.1...v15.1)

**Merged pull requests:**

-   Updated README.md [#&#8203;385](https://togithub.com/tj-actions/changed-files/pull/385) ([jackton1](https://togithub.com/jackton1))
-   feat: Added support for using fork point to detect file changes. [#&#8203;384](https://togithub.com/tj-actions/changed-files/pull/384) ([jackton1](https://togithub.com/jackton1))
-   Updated README.md [#&#8203;383](https://togithub.com/tj-actions/changed-files/pull/383) ([jackton1](https://togithub.com/jackton1))
-   Update README.md [#&#8203;381](https://togithub.com/tj-actions/changed-files/pull/381) ([jackton1](https://togithub.com/jackton1))
-   Update README.md [#&#8203;380](https://togithub.com/tj-actions/changed-files/pull/380) ([jackton1](https://togithub.com/jackton1))
-   Update diff-sha.sh [#&#8203;379](https://togithub.com/tj-actions/changed-files/pull/379) ([jackton1](https://togithub.com/jackton1))
-   Test pull request diff [#&#8203;378](https://togithub.com/tj-actions/changed-files/pull/378) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v15 [#&#8203;377](https://togithub.com/tj-actions/changed-files/pull/377) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v5.0.0 [#&#8203;375](https://togithub.com/tj-actions/changed-files/pull/375) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/sync-release-version action to v11 [#&#8203;374](https://togithub.com/tj-actions/changed-files/pull/374) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Updated README.md [#&#8203;373](https://togithub.com/tj-actions/changed-files/pull/373) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v14.7 [#&#8203;371](https://togithub.com/tj-actions/changed-files/pull/371) ([jackton1](https://togithub.com/jackton1))
-   chore: Cleanup duplicate action runs [#&#8203;370](https://togithub.com/tj-actions/changed-files/pull/370) ([jackton1](https://togithub.com/jackton1))
-   feat: Add support for excluding files via files-ignore input [#&#8203;369](https://togithub.com/tj-actions/changed-files/pull/369) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.7 [#&#8203;368](https://togithub.com/tj-actions/changed-files/pull/368) ([jackton1](https://togithub.com/jackton1))
-   fix: Bug detecting deleted files. [#&#8203;364](https://togithub.com/tj-actions/changed-files/pull/364) ([jackton1](https://togithub.com/jackton1))
-   chore: Update glob action inputs [#&#8203;363](https://togithub.com/tj-actions/changed-files/pull/363) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v14.6 [#&#8203;362](https://togithub.com/tj-actions/changed-files/pull/362) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.6 [#&#8203;361](https://togithub.com/tj-actions/changed-files/pull/361) ([jackton1](https://togithub.com/jackton1))
-   Update README.md [#&#8203;360](https://togithub.com/tj-actions/changed-files/pull/360) ([jackton1](https://togithub.com/jackton1))
-   Update README.md [#&#8203;359](https://togithub.com/tj-actions/changed-files/pull/359) ([jackton1](https://togithub.com/jackton1))
-   fix: Error with multiple changed files from merge commits [#&#8203;358](https://togithub.com/tj-actions/changed-files/pull/358) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/glob action to v7 [#&#8203;357](https://togithub.com/tj-actions/changed-files/pull/357) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Update reviewdog/action-shellcheck action to v1.14 [#&#8203;356](https://togithub.com/tj-actions/changed-files/pull/356) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v14.5 [#&#8203;352](https://togithub.com/tj-actions/changed-files/pull/352) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.5 [#&#8203;351](https://togithub.com/tj-actions/changed-files/pull/351) ([jackton1](https://togithub.com/jackton1))
-   feat: Add support for detecting submodules changes [#&#8203;350](https://togithub.com/tj-actions/changed-files/pull/350) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v14.4 [#&#8203;348](https://togithub.com/tj-actions/changed-files/pull/348) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.4 [#&#8203;347](https://togithub.com/tj-actions/changed-files/pull/347) ([jackton1](https://togithub.com/jackton1))
-   chore: expose internal files-separator input [#&#8203;346](https://togithub.com/tj-actions/changed-files/pull/346) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v14.3 [#&#8203;343](https://togithub.com/tj-actions/changed-files/pull/343) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.3 [#&#8203;342](https://togithub.com/tj-actions/changed-files/pull/342) ([jackton1](https://togithub.com/jackton1))
-   fix: resolve bug with pattern matching on windows [#&#8203;341](https://togithub.com/tj-actions/changed-files/pull/341) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v14.2 [#&#8203;339](https://togithub.com/tj-actions/changed-files/pull/339) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.2 [#&#8203;338](https://togithub.com/tj-actions/changed-files/pull/338) ([jackton1](https://togithub.com/jackton1))
-   bug: resolve issue with excluding files via glob pattern [#&#8203;337](https://togithub.com/tj-actions/changed-files/pull/337) ([jackton1](https://togithub.com/jackton1))
-   Bump peter-evans/create-pull-request from 3.12.0 to 3.12.1 [#&#8203;334](https://togithub.com/tj-actions/changed-files/pull/334) ([dependabot\[bot\]](https://togithub.com/apps/dependabot))
-   Upgraded to v14.1 [#&#8203;332](https://togithub.com/tj-actions/changed-files/pull/332) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.1 [#&#8203;331](https://togithub.com/tj-actions/changed-files/pull/331) ([jackton1](https://togithub.com/jackton1))
-   bug: Fix command to narrow down target files [#&#8203;330](https://togithub.com/tj-actions/changed-files/pull/330) ([massongit](https://togithub.com/massongit))
-   Upgraded to v14 [#&#8203;329](https://togithub.com/tj-actions/changed-files/pull/329) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v4.0.0 [#&#8203;328](https://togithub.com/tj-actions/changed-files/pull/328) ([jackton1](https://togithub.com/jackton1))
-   Clean up variable name to reflect usage. [#&#8203;327](https://togithub.com/tj-actions/changed-files/pull/327) ([jackton1](https://togithub.com/jackton1))
-   Narrow down target files by exact match of INPUT_FILES [#&#8203;326](https://togithub.com/tj-actions/changed-files/pull/326) ([massongit](https://togithub.com/massongit))
-   Upgraded to v13.2 [#&#8203;325](https://togithub.com/tj-actions/changed-files/pull/325) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v3.0.2 [#&#8203;324](https://togithub.com/tj-actions/changed-files/pull/324) ([jackton1](https://togithub.com/jackton1))
-   Updated README.md [#&#8203;323](https://togithub.com/tj-actions/changed-files/pull/323) ([jackton1](https://togithub.com/jackton1))
-   docs: add massongit as a contributor for code [#&#8203;322](https://togithub.com/tj-actions/changed-files/pull/322) ([allcontributors\[bot\]](https://togithub.com/apps/allcontributors))
-   Deduplicate from files parameter without sorting [#&#8203;321](https://togithub.com/tj-actions/changed-files/pull/321) ([massongit](https://togithub.com/massongit))
-   docs: add wushujames as a contributor for doc [#&#8203;320](https://togithub.com/tj-actions/changed-files/pull/320) ([allcontributors\[bot\]](https://togithub.com/apps/allcontributors))
-   String literals need to be inside single-quotes [#&#8203;319](https://togithub.com/tj-actions/changed-files/pull/319) ([wushujames](https://togithub.com/wushujames))
-   Remove redundant debug line [#&#8203;318](https://togithub.com/tj-actions/changed-files/pull/318) ([jackton1](https://togithub.com/jackton1))
-   Updated README.md [#&#8203;317](https://togithub.com/tj-actions/changed-files/pull/317) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v13.1 [#&#8203;316](https://togithub.com/tj-actions/changed-files/pull/316) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v3.0.1 [#&#8203;315](https://togithub.com/tj-actions/changed-files/pull/315) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/glob action to v3.3 [#&#8203;313](https://togithub.com/tj-actions/changed-files/pull/313) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Updated README.md [#&#8203;312](https://togithub.com/tj-actions/changed-files/pull/312) ([jackton1](https://togithub.com/jackton1))
-   Clean up unused code [#&#8203;311](https://togithub.com/tj-actions/changed-files/pull/311) ([jackton1](https://togithub.com/jackton1))
-   doc: add Zamiell as a contributor for doc [#&#8203;310](https://togithub.com/tj-actions/changed-files/pull/310) ([allcontributors\[bot\]](https://togithub.com/apps/allcontributors))
-   spelling/grammar [#&#8203;309](https://togithub.com/tj-actions/changed-files/pull/309) ([Zamiell](https://togithub.com/Zamiell))
-   Upgraded to v3.0.0 [#&#8203;308](https://togithub.com/tj-actions/changed-files/pull/308) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v13 [#&#8203;307](https://togithub.com/tj-actions/changed-files/pull/307) ([jackton1](https://togithub.com/jackton1))
-   Upgraded tj-actions/glob to v3.2 [#&#8203;306](https://togithub.com/tj-actions/changed-files/pull/306) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/remark action to v2.3 [#&#8203;305](https://togithub.com/tj-actions/changed-files/pull/305) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Add support for using github's glob pattern syntax [#&#8203;304](https://togithub.com/tj-actions/changed-files/pull/304) ([jackton1](https://togithub.com/jackton1))
-   Update tj-actions/remark action to v2 [#&#8203;302](https://togithub.com/tj-actions/changed-files/pull/302) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Bump tj-actions/github-changelog-generator from 1.10 to 1.11 [#&#8203;300](https://togithub.com/tj-actions/changed-files/pull/300) ([dependabot\[bot\]](https://togithub.com/apps/dependabot))
-   Update tj-actions/github-changelog-generator action to v1.10 [#&#8203;299](https://togithub.com/tj-actions/changed-files/pull/299) ([renovate\[bot\]](https://togithub.com/apps/renovate))
-   Upgraded to v2.0.1 [#&#8203;298](https://togithub.com/tj-actions/changed-files/pull/298) ([jackton1](https://togithub.com/jackton1))
-   Upgraded to v12.2 [#&#8203;297](https://togithub.com/tj-actions/changed-files/pull/297) ([jackton1](https://togithub.com/jackton1))

### [`v14.7`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v147-httpsgithubcomtj-actionschanged-filestreev147-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.6...v14.7)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v14.6...v14.7)

### [`v14.6`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v146-httpsgithubcomtj-actionschanged-filestreev146-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.5...v14.6)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v14.5...v14.6)

### [`v14.5`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v145-httpsgithubcomtj-actionschanged-filestreev145-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.4...v14.5)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v14.4...v14.5)

### [`v14.4`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v144-httpsgithubcomtj-actionschanged-filestreev144-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.3...v14.4)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v14.3...v14.4)

### [`v14.3`](https://togithub.com/tj-actions/changed-files/blob/HEAD/HISTORY.md#v143-httpsgithubcomtj-actionschanged-filestreev143-2022-02-17)

[Compare Source](https://togithub.com/tj-actions/changed-files/compare/v14.2...v14.3)

[Full Changelog](https://togithub.com/tj-actions/changed-files/compare/v14.2...v14.3)

</details>

---

---

#### 🐞 Fixes

- Update tj-actions/changed-files action to v24 [#431](https://github.com/pleo-io/centralized-templates/pull/431) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.1.5 (Thu Aug 11 2022)

### Release Notes

#### Update docker/login-action action to v2 ([#427](https://github.com/pleo-io/centralized-templates/pull/427))

<details>
<summary>docker/login-action</summary>

---

#### 🐞 Fixes

- Update docker/login-action action to v2 [#427](https://github.com/pleo-io/centralized-templates/pull/427) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.1.4 (Thu Aug 11 2022)

### Release Notes

#### Update unsplash/comment-on-pr action to v1.3.1 ([#433](https://github.com/pleo-io/centralized-templates/pull/433))

<details>
<summary>unsplash/comment-on-pr</summary>

---

#### 🐞 Fixes

- Update unsplash/comment-on-pr action to v1.3.1 [#433](https://github.com/pleo-io/centralized-templates/pull/433) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.1.3 (Thu Aug 11 2022)

### Release Notes

#### Update mikepenz/action-junit-report action to v2.9.1 ([#432](https://github.com/pleo-io/centralized-templates/pull/432))

<details>
<summary>mikepenz/action-junit-report</summary>

---

#### 🐞 Fixes

- Update mikepenz/action-junit-report action to v2.9.1 [#432](https://github.com/pleo-io/centralized-templates/pull/432) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

#### Authors: 1

- Renovate (Pleo) ([@pleo-bot-renovate](https://github.com/pleo-bot-renovate))

---

# v10.1.2 (Wed Aug 10 2022)

#### 🐞 Fixes

- Load resulting Docker images for later use [#434](https://github.com/pleo-io/centralized-templates/pull/434) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v10.1.1 (Wed Aug 10 2022)

#### 🐞 Fixes

- always checkout repository for snyk [#423](https://github.com/pleo-io/centralized-templates/pull/423) ([@steffkes](https://github.com/steffkes))

#### Authors: 1

- Stefan ([@steffkes](https://github.com/steffkes))

---

# v10.1.0 (Wed Aug 10 2022)

#### 🎁 Features

- [QE-893] Replace 'cancel-workflow-'action with GH Actions native cancel concurrent CI jobs feature [#422](https://github.com/pleo-io/centralized-templates/pull/422) ([@VictorPascualV](https://github.com/VictorPascualV) [@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Victor Pascual ([@VictorPascualV](https://github.com/VictorPascualV))

---

# v10.0.0 (Wed Aug 10 2022)

#### 💥 Major changes

- Speed up/modernize Docker layer caching [#421](https://github.com/pleo-io/centralized-templates/pull/421) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.4.0 (Wed Aug 10 2022)

#### 🎁 Features

- Avoid running Snyk if code changes have already been checked [#418](https://github.com/pleo-io/centralized-templates/pull/418) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### 🏠 Internal

- Fix Renovate Config for Github Actions [#420](https://github.com/pleo-io/centralized-templates/pull/420) ([@steffkes](https://github.com/steffkes))

#### Authors: 3

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Stefan ([@steffkes](https://github.com/steffkes))

---

# v9.3.0 (Mon Aug 08 2022)

#### 🎁 Features

- Auto-format Kotlin on push [#419](https://github.com/pleo-io/centralized-templates/pull/419) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.6 (Fri Aug 05 2022)

#### 🐞 Fixes

- Use default OpsLevel alias for OpenAPI spec push [#417](https://github.com/pleo-io/centralized-templates/pull/417) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.5 (Fri Aug 05 2022)

#### 🐞 Fixes

- Exit early on null OpsLevel service alias [#416](https://github.com/pleo-io/centralized-templates/pull/416) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.4 (Fri Aug 05 2022)

#### 🐞 Fixes

- Fix release yaml: add missing argument to retry [#414](https://github.com/pleo-io/centralized-templates/pull/414) ([@erwinw](https://github.com/erwinw) [@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Erwin Wessels ([@erwinw](https://github.com/erwinw))

---

# v9.2.3 (Fri Aug 05 2022)

#### 🐞 Fixes

- Only push to OpsLevel on the default branch [#415](https://github.com/pleo-io/centralized-templates/pull/415) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.2 (Thu Aug 04 2022)

#### 🐞 Fixes

- Use up-to-date yq in releases [#413](https://github.com/pleo-io/centralized-templates/pull/413) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.1 (Thu Aug 04 2022)

#### 🐞 Fixes

- Ensure up-to-date yq version in release YAML processing [#412](https://github.com/pleo-io/centralized-templates/pull/412) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.2.0 (Thu Aug 04 2022)

#### 🎁 Features

- Push OpenAPI spec to OpsLevel on client generation [#411](https://github.com/pleo-io/centralized-templates/pull/411) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@dpotyralski](https://github.com/dpotyralski))

#### Authors: 2

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Damian Potyralski ([@dpotyralski](https://github.com/dpotyralski))

---

# v9.1.0 (Thu Aug 04 2022)

#### 🎁 Features

- Add 'build-and-test' workflow [#410](https://github.com/pleo-io/centralized-templates/pull/410) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v9.0.1 (Thu Aug 04 2022)

#### 🐞 Fixes

- Let Renovate pass CI when labels aren't present [#409](https://github.com/pleo-io/centralized-templates/pull/409) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### 🏠 Internal

- fix: modified link to DD logs in order to include the index and source filters [#406](https://github.com/pleo-io/centralized-templates/pull/406) ([@andrea-del-popolo](https://github.com/andrea-del-popolo))
- chore(templates): update repository configuration from templates [#408](https://github.com/pleo-io/centralized-templates/pull/408) (dev@pleo.io [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor))

#### Authors: 4

- [@pleo-bot-file-distributor](https://github.com/pleo-bot-file-distributor)
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Andrea ([@andrea-del-popolo](https://github.com/andrea-del-popolo))
- pleo-io (dev@pleo.io)

---

# v9.0.0 (Wed Aug 03 2022)

#### 💥 Major changes

- Replace 'gradle-cache-action' with 'gradle-build-action' [#407](https://github.com/pleo-io/centralized-templates/pull/407) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### ⚠️ Pushed to `main`

- Remove commenting workflow ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### 🏠 Internal

- Remove redundant Auto tag parameter in release [#404](https://github.com/pleo-io/centralized-templates/pull/404) ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Fix unsupported array literal [#403](https://github.com/pleo-io/centralized-templates/pull/403) ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Avoid commenting on Auto arbitrary output [#402](https://github.com/pleo-io/centralized-templates/pull/402) ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Comment on PRs after finished release [#401](https://github.com/pleo-io/centralized-templates/pull/401) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.23.1 (Tue Aug 02 2022)

#### 🐞 Fixes

- Add comments to templates for easier reviews [#400](https://github.com/pleo-io/centralized-templates/pull/400) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.23.0 (Tue Aug 02 2022)

#### 🎁 Features

- Use properties parameter for Gradle cache action invocation [#398](https://github.com/pleo-io/centralized-templates/pull/398) ([@andersfischernielsen](https://github.com/andersfischernielsen) [@kodiakhq[bot]](https://github.com/kodiakhq[bot]))

#### Authors: 2

- [@kodiakhq[bot]](https://github.com/kodiakhq[bot])
- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.22.0 (Tue Aug 02 2022)

#### 🎁 Features

- Add retry to http call to opslevel [#399](https://github.com/pleo-io/centralized-templates/pull/399) ([@marcos-arranz](https://github.com/marcos-arranz))

#### Authors: 1

- Marcos Arranz ([@marcos-arranz](https://github.com/marcos-arranz))

---

# v8.21.1 (Mon Aug 01 2022)

#### 🐞 Fixes

- Improve rate limit handling in release jobs [#397](https://github.com/pleo-io/centralized-templates/pull/397) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### ⚠️ Pushed to `main`

- Fix dataDogTestLoggingEnabled templating errors ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.21.0 (Mon Aug 01 2022)

#### 🎁 Features

- feat: Show stacktrace in Gradle invocations for easier debugging [#394](https://github.com/pleo-io/centralized-templates/pull/394) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### ⚠️ Pushed to `main`

- Remove dependency on package.json during release ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Use recent main as checkout reference for release ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Fix NPX invocation of Auto ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Use NPX for Auto release ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.20.0 (Mon Aug 01 2022)

#### 🎁 Features

- Fix Auto release token issues [#396](https://github.com/pleo-io/centralized-templates/pull/396) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### ⚠️ Pushed to `main`

- Checkout tags on release ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Fix incorrect Auto invocation in release ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Use CLI auto for releases ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Remove default branch specificer in release workflow ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Add GH_TOKEN to release workflow ([@andersfischernielsen](https://github.com/andersfischernielsen))
- Add debug information ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

# v8.19.0 (Mon Aug 01 2022)

#### 🎁 Features

- Use Auto for releases [#393](https://github.com/pleo-io/centralized-templates/pull/393) ([@andersfischernielsen](https://github.com/andersfischernielsen))

#### Authors: 1

- Anders Fischer-Nielsen ([@andersfischernielsen](https://github.com/andersfischernielsen))

---

## [8.18.1](https://github.com/pleo-io/centralized-templates/compare/v8.18.0...v8.18.1) (2022-07-29)


### Bug Fixes

* Set Node version before JS client generation ([#395](https://github.com/pleo-io/centralized-templates/issues/395)) ([6ef8424](https://github.com/pleo-io/centralized-templates/commit/6ef8424a36372d1fc403d2969801abb1ccd5dfea))

# [8.18.0](https://github.com/pleo-io/centralized-templates/compare/v8.17.0...v8.18.0) (2022-07-28)


### Features

* Validate OpsLevel Configuration ([#383](https://github.com/pleo-io/centralized-templates/issues/383)) ([e6daf53](https://github.com/pleo-io/centralized-templates/commit/e6daf532b05e38ffe11f7022641bcd17689f9b15))

# [8.17.0](https://github.com/pleo-io/centralized-templates/compare/v8.16.4...v8.17.0) (2022-07-25)


### Features

* Split test and check jobs for TypeScript workflows ([#392](https://github.com/pleo-io/centralized-templates/issues/392)) ([765c897](https://github.com/pleo-io/centralized-templates/commit/765c897c0e6fd5e0f2c96081873460de31705eb8))

## [8.16.4](https://github.com/pleo-io/centralized-templates/compare/v8.16.3...v8.16.4) (2022-07-25)


### Bug Fixes

* Make template release dependent on template formatting ([#390](https://github.com/pleo-io/centralized-templates/issues/390)) ([60223d3](https://github.com/pleo-io/centralized-templates/commit/60223d3056eacbbc03d673fd54e7f710d8ee05da))

## [8.16.2](https://github.com/pleo-io/centralized-templates/compare/v8.16.1...v8.16.2) (2022-07-25)


### Bug Fixes

* Revert templates to pre-format state and re-format ([#388](https://github.com/pleo-io/centralized-templates/issues/388)) ([d9f7ee9](https://github.com/pleo-io/centralized-templates/commit/d9f7ee9edca8b74d93405477a01b1225e173cba2))

## [8.16.1](https://github.com/pleo-io/centralized-templates/compare/v8.16.0...v8.16.1) (2022-07-25)


### Bug Fixes

* Format templates to ensure consistency ([#385](https://github.com/pleo-io/centralized-templates/issues/385)) ([a3a3926](https://github.com/pleo-io/centralized-templates/commit/a3a39261790744b615d4fac86829458d2a0ada35))

# [8.16.0](https://github.com/pleo-io/centralized-templates/compare/v8.15.0...v8.16.0) (2022-07-22)


### Features

* Use open-source CICD cache Action ([#384](https://github.com/pleo-io/centralized-templates/issues/384)) ([166e88e](https://github.com/pleo-io/centralized-templates/commit/166e88e0c5d72c0d8e0b6bc489156f3d6bd89b03))

# [8.15.0](https://github.com/pleo-io/centralized-templates/compare/v8.14.0...v8.15.0) (2022-07-22)


### Features

* Add s3 cache for typescript ecr template ([#382](https://github.com/pleo-io/centralized-templates/issues/382)) ([1431fc4](https://github.com/pleo-io/centralized-templates/commit/1431fc4020ee7ee2582ca4ce45c951aad760dbb5))

# [8.14.0](https://github.com/pleo-io/centralized-templates/compare/v8.13.3...v8.14.0) (2022-07-21)


### Features

* Skip tests for commits which have previously been tested in Kotlin repositories ([#379](https://github.com/pleo-io/centralized-templates/issues/379)) ([2b26a0a](https://github.com/pleo-io/centralized-templates/commit/2b26a0a221d9be2b304d581834997f5da07abd48))

## [8.13.2](https://github.com/pleo-io/centralized-templates/compare/v8.13.1...v8.13.2) (2022-07-18)


### Bug Fixes

* Fix hardcoded default branch name in release ([#380](https://github.com/pleo-io/centralized-templates/issues/380)) ([c3e9ce8](https://github.com/pleo-io/centralized-templates/commit/c3e9ce8a27733621c0116c994668aeafb3cfa1b9))

## [8.13.1](https://github.com/pleo-io/centralized-templates/compare/v8.13.0...v8.13.1) (2022-07-15)


### Bug Fixes

* Avoid node package-lock version conflicts in release ([#375](https://github.com/pleo-io/centralized-templates/issues/375)) ([d78353f](https://github.com/pleo-io/centralized-templates/commit/d78353f0762da80dc0fb8c524b0896ae2dcba3b7))

# [8.13.0](https://github.com/pleo-io/centralized-templates/compare/v8.12.2...v8.13.0) (2022-07-15)


### Features

* Add Snyk test send to OpsLevel step ([#371](https://github.com/pleo-io/centralized-templates/issues/371)) ([b77c17b](https://github.com/pleo-io/centralized-templates/commit/b77c17b8833c12ccec6d3e2d24826be7f42bcc2d))

## [8.12.2](https://github.com/pleo-io/centralized-templates/compare/v8.12.1...v8.12.2) (2022-07-15)


### Bug Fixes

* Ignore main branch for template linting ([#374](https://github.com/pleo-io/centralized-templates/issues/374)) ([18bcc03](https://github.com/pleo-io/centralized-templates/commit/18bcc034e7468c056308f50a9d57aceeb75a05a3))

## [8.12.1](https://github.com/pleo-io/centralized-templates/compare/v8.12.0...v8.12.1) (2022-07-15)


### Bug Fixes

* Remove redundant steps in validation ([#373](https://github.com/pleo-io/centralized-templates/issues/373)) ([82dba22](https://github.com/pleo-io/centralized-templates/commit/82dba229808fb21a7278d1cbf4e293a04359856c))

# [8.12.0](https://github.com/pleo-io/centralized-templates/compare/v8.11.3...v8.12.0) (2022-07-15)


### Features

* Lint templated files ([#372](https://github.com/pleo-io/centralized-templates/issues/372)) ([8a584ee](https://github.com/pleo-io/centralized-templates/commit/8a584eecd1e6b4f7f60bbb82760bf9f104d6c5d8))

## [8.11.3](https://github.com/pleo-io/centralized-templates/compare/v8.11.2...v8.11.3) (2022-07-12)


### Bug Fixes

* GitHub contexts properties used for OpsLevel notifications ([#369](https://github.com/pleo-io/centralized-templates/issues/369)) ([62cd0b3](https://github.com/pleo-io/centralized-templates/commit/62cd0b3369253658c6c99a27bde07b4ad65b28b2))

## [8.11.1](https://github.com/pleo-io/centralized-templates/compare/v8.11.0...v8.11.1) (2022-07-11)


### Bug Fixes

* Simplify release step conditions ([#366](https://github.com/pleo-io/centralized-templates/issues/366)) ([661db48](https://github.com/pleo-io/centralized-templates/commit/661db48593272de6177749cd6235cce2bbe6027d))

# [8.11.0](https://github.com/pleo-io/centralized-templates/compare/v8.10.0...v8.11.0) (2022-07-11)


### Features

* Split release workflow into individual jobs ([#365](https://github.com/pleo-io/centralized-templates/issues/365)) ([4690a45](https://github.com/pleo-io/centralized-templates/commit/4690a4519fea127e6ee9d403a6bc0572895256cb))

# [8.10.0](https://github.com/pleo-io/centralized-templates/compare/v8.9.3...v8.10.0) (2022-07-11)


### Features

* Enable OpsLevel notifications for production deploys ([#364](https://github.com/pleo-io/centralized-templates/issues/364)) ([3d337d8](https://github.com/pleo-io/centralized-templates/commit/3d337d8f76e8c4b8d1a23664dbc6fe7b34ece2ee))

## [8.9.3](https://github.com/pleo-io/centralized-templates/compare/v8.9.2...v8.9.3) (2022-06-28)


### Bug Fixes

* Support multiple CODEOWNERS teams in review assignment ([#362](https://github.com/pleo-io/centralized-templates/issues/362)) ([c0a186c](https://github.com/pleo-io/centralized-templates/commit/c0a186c12065a2c2fd5d1f1b530f38fed5e312b9))

## [8.9.2](https://github.com/pleo-io/centralized-templates/compare/v8.9.1...v8.9.2) (2022-06-22)


### Bug Fixes

* **ci:** Replace Slack webhook url with GH secret ([#360](https://github.com/pleo-io/centralized-templates/issues/360)) ([576f9eb](https://github.com/pleo-io/centralized-templates/commit/576f9eb17749be41f1316a059ae9d77172e1890b))

## [8.9.1](https://github.com/pleo-io/centralized-templates/compare/v8.9.0...v8.9.1) (2022-06-22)


### Bug Fixes

* **ci:** Fix Slack webhook for deploy failures ([#359](https://github.com/pleo-io/centralized-templates/issues/359)) ([9b17d49](https://github.com/pleo-io/centralized-templates/commit/9b17d497e8de22d2d1d1ed90cf204420798e14d2))

# [8.9.0](https://github.com/pleo-io/centralized-templates/compare/v8.8.1...v8.9.0) (2022-06-22)


### Features

* Add Danger workflow for PR assistance ([#357](https://github.com/pleo-io/centralized-templates/issues/357)) ([1f937b7](https://github.com/pleo-io/centralized-templates/commit/1f937b7a5fc80c643062e830a452f9ec25fe7478))

## [8.8.1](https://github.com/pleo-io/centralized-templates/compare/v8.8.0...v8.8.1) (2022-06-21)


### Bug Fixes

* Remove redundant CODEOWNERS validation step leading to failures ([#358](https://github.com/pleo-io/centralized-templates/issues/358)) ([5b7f942](https://github.com/pleo-io/centralized-templates/commit/5b7f942e00cf490d0f0ac6a46b9b181b9cc81025))

# [8.8.0](https://github.com/pleo-io/centralized-templates/compare/v8.7.4...v8.8.0) (2022-06-17)


### Features

* Add team member assignment workflow ([#356](https://github.com/pleo-io/centralized-templates/issues/356)) ([2190f2c](https://github.com/pleo-io/centralized-templates/commit/2190f2c94df83d0d3e23d57caa0546b8825a261d))

## [8.7.4](https://github.com/pleo-io/centralized-templates/compare/v8.7.3...v8.7.4) (2022-06-16)


### Bug Fixes

* **snyk:** Enable missing Snyk monitor step for merges to default branches ([#355](https://github.com/pleo-io/centralized-templates/issues/355)) ([c1474b8](https://github.com/pleo-io/centralized-templates/commit/c1474b8f79c8a6224842f900f811abc585f7c11e))

## [8.7.3](https://github.com/pleo-io/centralized-templates/compare/v8.7.2...v8.7.3) (2022-06-15)


### Bug Fixes

* **cicd:** Enable 'agentless mode' for reporting test results to Datadog ([#354](https://github.com/pleo-io/centralized-templates/issues/354)) ([972849c](https://github.com/pleo-io/centralized-templates/commit/972849c156f16574951d261c168a0424ff2d227e))

## [8.7.2](https://github.com/pleo-io/centralized-templates/compare/v8.7.1...v8.7.2) (2022-06-13)


### Bug Fixes

* **snyk:** Fix Snyk exit code failing too early ([#353](https://github.com/pleo-io/centralized-templates/issues/353)) ([3c90986](https://github.com/pleo-io/centralized-templates/commit/3c90986060d22bf8275f92202e82f37e459451e6))

## [8.7.1](https://github.com/pleo-io/centralized-templates/compare/v8.7.0...v8.7.1) (2022-06-09)


### Bug Fixes

* **dora-metrics:** properly indent report-deploy step ([#351](https://github.com/pleo-io/centralized-templates/issues/351)) ([f4215da](https://github.com/pleo-io/centralized-templates/commit/f4215da7485e0280d2621cd7bbf5ada2c4a8656a))

# [8.7.0](https://github.com/pleo-io/centralized-templates/compare/v8.6.0...v8.7.0) (2022-06-06)


### Features

* **dora-metrics:** release DORA metrics reporting implemented in pull request 348 ([#349](https://github.com/pleo-io/centralized-templates/issues/349)) ([d6683f3](https://github.com/pleo-io/centralized-templates/commit/d6683f38089b6b55e62dced02ad59763c7021c41))

# [8.6.0](https://github.com/pleo-io/centralized-templates/compare/v8.5.7...v8.6.0) (2022-05-30)


### Features

* **stuck-prs:** Create workflow for commenting on stuck PRs ([#343](https://github.com/pleo-io/centralized-templates/issues/343)) ([f8a609b](https://github.com/pleo-io/centralized-templates/commit/f8a609b706ea612f8d667a6dcea182b73924f60a))

## [8.5.7](https://github.com/pleo-io/centralized-templates/compare/v8.5.6...v8.5.7) (2022-05-30)


### Bug Fixes

* Use temurin instead of adopt JDK ([#344](https://github.com/pleo-io/centralized-templates/issues/344)) ([d2771c8](https://github.com/pleo-io/centralized-templates/commit/d2771c86cae5d09c4fcfd9b700dbe0983c771105))

## [8.5.6](https://github.com/pleo-io/centralized-templates/compare/v8.5.5...v8.5.6) (2022-05-27)


### Bug Fixes

* **release:** Add Slack alerting for partial library release failures ([#342](https://github.com/pleo-io/centralized-templates/issues/342)) ([4fb22b5](https://github.com/pleo-io/centralized-templates/commit/4fb22b5f88487cf26be833516cb0a16e48cfdd96))

## [8.5.5](https://github.com/pleo-io/centralized-templates/compare/v8.5.4...v8.5.5) (2022-05-25)


### Bug Fixes

* **release:** Allow release to continue on subproject release failure ([#341](https://github.com/pleo-io/centralized-templates/issues/341)) ([0ea1f64](https://github.com/pleo-io/centralized-templates/commit/0ea1f6444c190e4c267e4b73f6d9ce4527883f0a))

## [8.5.4](https://github.com/pleo-io/centralized-templates/compare/v8.5.3...v8.5.4) (2022-05-18)


### Bug Fixes

* **build_kotlin_ecr:** Fix Docker conflict in local DataDog step ([#339](https://github.com/pleo-io/centralized-templates/issues/339)) ([8da2e1c](https://github.com/pleo-io/centralized-templates/commit/8da2e1c8df6bb5072f0dcc550db1b1db5b8c99f4))

## [8.5.3](https://github.com/pleo-io/centralized-templates/compare/v8.5.2...v8.5.3) (2022-05-06)


### Bug Fixes

* **build_kotlin_ecr:** Add missing gradle read key to deploy script ([#338](https://github.com/pleo-io/centralized-templates/issues/338)) ([0f76a50](https://github.com/pleo-io/centralized-templates/commit/0f76a50ab71889093d2796c81469c3cac7575fff))

## [8.5.2](https://github.com/pleo-io/centralized-templates/compare/v8.5.1...v8.5.2) (2022-05-02)


### Bug Fixes

* **build_kotlin_ecr:** Add missing Gradle key ([#335](https://github.com/pleo-io/centralized-templates/issues/335)) ([7d10786](https://github.com/pleo-io/centralized-templates/commit/7d10786275a10947d8d1a681caab9a52ccdc3458))

## [8.5.1](https://github.com/pleo-io/centralized-templates/compare/v8.5.0...v8.5.1) (2022-04-29)


### Bug Fixes

* **verify-release:** Remove slow label creation step ([#334](https://github.com/pleo-io/centralized-templates/issues/334)) ([50c5e28](https://github.com/pleo-io/centralized-templates/commit/50c5e28402319e281de5840e2d3d6325341aebf0))

# [8.5.0](https://github.com/pleo-io/centralized-templates/compare/v8.4.2...v8.5.0) (2022-04-29)


### Features

* **release:** Ensure repository labels are present before verification ([#333](https://github.com/pleo-io/centralized-templates/issues/333)) ([8c30642](https://github.com/pleo-io/centralized-templates/commit/8c30642acf1cef8088a1e064be859d4251c09937))

## [8.4.2](https://github.com/pleo-io/centralized-templates/compare/v8.4.1...v8.4.2) (2022-04-29)


### Bug Fixes

* **release:** Properly exit on Gradle failures ([#332](https://github.com/pleo-io/centralized-templates/issues/332)) ([50461d7](https://github.com/pleo-io/centralized-templates/commit/50461d7fd212896cd101dc2673af1f7880d34448))

## [8.4.1](https://github.com/pleo-io/centralized-templates/compare/v8.4.0...v8.4.1) (2022-04-28)


### Bug Fixes

* **snyk:** Remove unreadable full vulnerability path information ([#331](https://github.com/pleo-io/centralized-templates/issues/331)) ([1a8342c](https://github.com/pleo-io/centralized-templates/commit/1a8342cdd6751fdfc9e9066d74199a8aa1ba56d7))

# [8.4.0](https://github.com/pleo-io/centralized-templates/compare/v8.3.1...v8.4.0) (2022-04-28)


### Features

* **snyk:** Ensure Snyk only blocks patchable vulnerabilities ([#330](https://github.com/pleo-io/centralized-templates/issues/330)) ([2892991](https://github.com/pleo-io/centralized-templates/commit/2892991def449b5f2be8f543db01e82baa413af8))

## [8.3.1](https://github.com/pleo-io/centralized-templates/compare/v8.3.0...v8.3.1) (2022-04-27)


### Bug Fixes

* **snyk:** Handle retries in Snyk checks ([#329](https://github.com/pleo-io/centralized-templates/issues/329)) ([c0c400b](https://github.com/pleo-io/centralized-templates/commit/c0c400be93d9be55d30b8a2537c20bd992ed9f29))

# [8.3.0](https://github.com/pleo-io/centralized-templates/compare/v8.2.4...v8.3.0) (2022-04-13)


### Features

* **snyk:** Run Snyk for PRs only ([#328](https://github.com/pleo-io/centralized-templates/issues/328)) ([36eb210](https://github.com/pleo-io/centralized-templates/commit/36eb210079668f3ac55c25029bd4d9c0f680307c))

## [8.2.4](https://github.com/pleo-io/centralized-templates/compare/v8.2.3...v8.2.4) (2022-04-08)


### Bug Fixes

* **release:** Skip token elevation if internal release ([#327](https://github.com/pleo-io/centralized-templates/issues/327)) ([59c9ef1](https://github.com/pleo-io/centralized-templates/commit/59c9ef1a94b69e8e74fd787379675947de42cd81))

## [8.2.3](https://github.com/pleo-io/centralized-templates/compare/v8.2.2...v8.2.3) (2022-04-08)


### Bug Fixes

* **snyk:** Add missing Gradle token for moons that require it ([#326](https://github.com/pleo-io/centralized-templates/issues/326)) ([ad7e01e](https://github.com/pleo-io/centralized-templates/commit/ad7e01e3781d9210aa53bb8f76c54e08ea3b6d38))

## [8.2.2](https://github.com/pleo-io/centralized-templates/compare/v8.2.1...v8.2.2) (2022-04-08)


### Bug Fixes

* **snyk:** Add missing retry parameter ([#325](https://github.com/pleo-io/centralized-templates/issues/325)) ([a044068](https://github.com/pleo-io/centralized-templates/commit/a044068a4ea886b2cb8387c4e58167b6a4e9f514))

## [8.2.1](https://github.com/pleo-io/centralized-templates/compare/v8.2.0...v8.2.1) (2022-04-08)


### Bug Fixes

* **build_kotlin_ecr:** Add missing Gradle token for moons ([#324](https://github.com/pleo-io/centralized-templates/issues/324)) ([c903b2e](https://github.com/pleo-io/centralized-templates/commit/c903b2ef3980a08b79e1785bf4e60ebb0704c45b))

# [8.2.0](https://github.com/pleo-io/centralized-templates/compare/v8.1.1...v8.2.0) (2022-04-07)


### Features

* **snyk:** Retry Snyk test on exit code 2 ([#323](https://github.com/pleo-io/centralized-templates/issues/323)) ([6ddf035](https://github.com/pleo-io/centralized-templates/commit/6ddf035e877fefc65fc776d1a49577026162873f))

## [8.1.1](https://github.com/pleo-io/centralized-templates/compare/v8.1.0...v8.1.1) (2022-04-06)


### Bug Fixes

* **verify-release:** Remove problematic version check ([#322](https://github.com/pleo-io/centralized-templates/issues/322)) ([7f25568](https://github.com/pleo-io/centralized-templates/commit/7f25568a0134220af6a2fa7aed0013607774de5e))

# [8.1.0](https://github.com/pleo-io/centralized-templates/compare/v8.0.4...v8.1.0) (2022-04-06)


### Features

* **release:** Verify previous release tag on change calculation ([#321](https://github.com/pleo-io/centralized-templates/issues/321)) ([e96f370](https://github.com/pleo-io/centralized-templates/commit/e96f370c43061d9512856b303b5313b7334699a2))

## [8.0.4](https://github.com/pleo-io/centralized-templates/compare/v8.0.3...v8.0.4) (2022-04-05)


### Bug Fixes

* **verify-release:** Remove redundant brackets ([#320](https://github.com/pleo-io/centralized-templates/issues/320)) ([b2a8349](https://github.com/pleo-io/centralized-templates/commit/b2a8349d579d7b9bb895f45d749426564c3028b4))

## [8.0.3](https://github.com/pleo-io/centralized-templates/compare/v8.0.2...v8.0.3) (2022-04-05)


### Bug Fixes

* **release:** adding tokens to fix auth issue ([#319](https://github.com/pleo-io/centralized-templates/issues/319)) ([ecd1092](https://github.com/pleo-io/centralized-templates/commit/ecd109250f4b89bcee88ddcd20a7ab2108dc382f))

## [8.0.2](https://github.com/pleo-io/centralized-templates/compare/v8.0.1...v8.0.2) (2022-03-31)


### Bug Fixes

* **release:** Add concurrency flag to release job ([#316](https://github.com/pleo-io/centralized-templates/issues/316)) ([93a355e](https://github.com/pleo-io/centralized-templates/commit/93a355ec72d4eae920bc3b1b689339dd06891e22))

## [8.0.1](https://github.com/pleo-io/centralized-templates/compare/v8.0.0...v8.0.1) (2022-03-31)


### Bug Fixes

* **release:** Fix inverted conditional, double variable assignment ([#315](https://github.com/pleo-io/centralized-templates/issues/315)) ([ab31295](https://github.com/pleo-io/centralized-templates/commit/ab312957bdcad083c59fe1365454a3634fc87151))

## [7.0.2](https://github.com/pleo-io/centralized-templates/compare/v7.0.1...v7.0.2) (2022-03-31)


### Bug Fixes

* **release:** Fix POSIX incompliance in release.yaml ([#313](https://github.com/pleo-io/centralized-templates/issues/313)) ([02775dc](https://github.com/pleo-io/centralized-templates/commit/02775dc1797a32ce12f732c1fc5ff900fe637ef0))

## [7.0.1](https://github.com/pleo-io/centralized-templates/compare/v7.0.0...v7.0.1) (2022-03-30)


### Bug Fixes

* **snyk:** Set up Java environment before Snyk test ([#312](https://github.com/pleo-io/centralized-templates/issues/312)) ([dd6c52f](https://github.com/pleo-io/centralized-templates/commit/dd6c52f66a5fa493206bb1c5f47bf0a900ec34fc))

# [7.0.0](https://github.com/pleo-io/centralized-templates/compare/v6.22.2...v7.0.0) (2022-03-25)


* feat!(release): Support independent versioning of subprojects in library release workflow (#311) ([b74be15](https://github.com/pleo-io/centralized-templates/commit/b74be15335ad896ba56e94667ee02575c5aa8201)), closes [#311](https://github.com/pleo-io/centralized-templates/issues/311)


### BREAKING CHANGES

* This will release subprojects in libraries individually and requires having a version set in each individual subproject of a library.

## [6.22.2](https://github.com/pleo-io/centralized-templates/compare/v6.22.1...v6.22.2) (2022-03-25)


### Bug Fixes

* **build-kotlin-ecr:** Ensure Slack alerting on failure ([#310](https://github.com/pleo-io/centralized-templates/issues/310)) ([d7f6a1a](https://github.com/pleo-io/centralized-templates/commit/d7f6a1ab501e23a399b7e14b61900197a25e5c47))

## [6.22.1](https://github.com/pleo-io/centralized-templates/compare/v6.22.0...v6.22.1) (2022-03-24)


### Bug Fixes

* **kodiak:** Add missing comment tags ([#309](https://github.com/pleo-io/centralized-templates/issues/309)) ([d2362e6](https://github.com/pleo-io/centralized-templates/commit/d2362e688f703455029e77864c1abe02c1ba9bd7))

# [6.22.0](https://github.com/pleo-io/centralized-templates/compare/v6.21.0...v6.22.0) (2022-03-24)


### Features

* **kodiak:** Add option for Kodiak auto-approve of Renovate PRs ([#308](https://github.com/pleo-io/centralized-templates/issues/308)) ([d39b379](https://github.com/pleo-io/centralized-templates/commit/d39b379dbbc129a7587dfdb0443fbf289a38a257))

# [6.21.0](https://github.com/pleo-io/centralized-templates/compare/v6.20.7...v6.21.0) (2022-03-21)


### Features

* **release:** Add retries to Gradle library release step ([#306](https://github.com/pleo-io/centralized-templates/issues/306)) ([b6607c2](https://github.com/pleo-io/centralized-templates/commit/b6607c26959a99746f35a11e315651e5e8552f2e))

## [6.20.7](https://github.com/pleo-io/centralized-templates/compare/v6.20.6...v6.20.7) (2022-03-18)


### Bug Fixes

* **verify-release:** Add missing environment tokens ([#304](https://github.com/pleo-io/centralized-templates/issues/304)) ([98ee5eb](https://github.com/pleo-io/centralized-templates/commit/98ee5ebe8b4549b67a979c38fe31a47a403a299a))

## [6.20.6](https://github.com/pleo-io/centralized-templates/compare/v6.20.5...v6.20.6) (2022-03-15)


### Bug Fixes

* **release:** Avoid attempt to tag and commit if no changes are present ([#298](https://github.com/pleo-io/centralized-templates/issues/298)) ([7c981d9](https://github.com/pleo-io/centralized-templates/commit/7c981d96d8da67801e9e5d57b2ef9a495984fff6))

## [6.20.5](https://github.com/pleo-io/centralized-templates/compare/v6.20.4...v6.20.5) (2022-03-15)


### Bug Fixes

* **release:** Fix too general version regex ([#303](https://github.com/pleo-io/centralized-templates/issues/303)) ([8c04792](https://github.com/pleo-io/centralized-templates/commit/8c0479275ecf624666fdccce1fbd9e27489e270e))

## [6.20.4](https://github.com/pleo-io/centralized-templates/compare/v6.20.3...v6.20.4) (2022-03-11)


### Bug Fixes

* **publish_libaray_typescript:** Add an empty NPM_TOKEN variable to prevent errors ([#301](https://github.com/pleo-io/centralized-templates/issues/301)) ([36f79f7](https://github.com/pleo-io/centralized-templates/commit/36f79f784cd65991e265c70a6d605e15c051fb9c))

## [6.20.3](https://github.com/pleo-io/centralized-templates/compare/v6.20.2...v6.20.3) (2022-03-07)


### Bug Fixes

* **build-kotlin-ecr:** Remove redundant build trigger ([#294](https://github.com/pleo-io/centralized-templates/issues/294)) ([daa6e22](https://github.com/pleo-io/centralized-templates/commit/daa6e2266371a8e1799b1a13022e78c2088157f4))

## [6.20.2](https://github.com/pleo-io/centralized-templates/compare/v6.20.1...v6.20.2) (2022-03-04)


### Bug Fixes

* **release:** Move incorrectly placed fetch-depth ([#299](https://github.com/pleo-io/centralized-templates/issues/299)) ([9e052ee](https://github.com/pleo-io/centralized-templates/commit/9e052eeecc8b74431ee3c2cdb9e4ce67f70cb7c5))

## [6.20.1](https://github.com/pleo-io/centralized-templates/compare/v6.20.0...v6.20.1) (2022-03-04)


### Bug Fixes

* **snyk:** Allow monitor step to continue on failure ([#295](https://github.com/pleo-io/centralized-templates/issues/295)) ([e7d3911](https://github.com/pleo-io/centralized-templates/commit/e7d39117dc89411da86cb9b9ab9b22cda82d2e75))

# [6.20.0](https://github.com/pleo-io/centralized-templates/compare/v6.19.0...v6.20.0) (2022-03-04)


### Features

* **verify-release:** Ensure no manual changes to version ([#297](https://github.com/pleo-io/centralized-templates/issues/297)) ([b027ec0](https://github.com/pleo-io/centralized-templates/commit/b027ec08bb36009d27b5818843aa0293ef8faa9c))

# [6.19.0](https://github.com/pleo-io/centralized-templates/compare/v6.18.2...v6.19.0) (2022-03-03)


### Features

* **release:** Add Renovate author detection to release verification ([#292](https://github.com/pleo-io/centralized-templates/issues/292)) ([db1075d](https://github.com/pleo-io/centralized-templates/commit/db1075defd33a13d905769f02f5be3b71d1bcc6e))

## [6.18.2](https://github.com/pleo-io/centralized-templates/compare/v6.18.1...v6.18.2) (2022-03-03)


### Bug Fixes

* **release:** Prevent release if library is unchanged ([#293](https://github.com/pleo-io/centralized-templates/issues/293)) ([2a286db](https://github.com/pleo-io/centralized-templates/commit/2a286dbec9ed640297acc37cb42021975cb10b98))

## [6.18.1](https://github.com/pleo-io/centralized-templates/compare/v6.18.0...v6.18.1) (2022-03-03)


### Bug Fixes

* **build-kotlin-ecr:** Remove redundant end statement ([#291](https://github.com/pleo-io/centralized-templates/issues/291)) ([4f88f96](https://github.com/pleo-io/centralized-templates/commit/4f88f9682d4e50c661c80ad4d65920b9bd322046))

# [6.18.0](https://github.com/pleo-io/centralized-templates/compare/v6.17.1...v6.18.0) (2022-03-03)


### Features

* **release:** Add Slack alert on release failure ([#285](https://github.com/pleo-io/centralized-templates/issues/285)) ([0e7e51d](https://github.com/pleo-io/centralized-templates/commit/0e7e51d9cde7eb3992f690d8d83d855acda63da4))

## [6.17.1](https://github.com/pleo-io/centralized-templates/compare/v6.17.0...v6.17.1) (2022-03-02)


### Bug Fixes

* **build-kotlin-ecr:** Correct typo in template [#284](https://github.com/pleo-io/centralized-templates/issues/284) ([bf5173e](https://github.com/pleo-io/centralized-templates/commit/bf5173efbed38fc7414cc6c93120b829f1367113))

# [6.17.0](https://github.com/pleo-io/centralized-templates/compare/v6.16.0...v6.17.0) (2022-03-02)


### Features

* **release:** Trigger release [#282](https://github.com/pleo-io/centralized-templates/issues/282) ([#283](https://github.com/pleo-io/centralized-templates/issues/283)) ([457d797](https://github.com/pleo-io/centralized-templates/commit/457d79702d7a94abd04267ff35067ee4ba8bc7a2))

# [6.16.0](https://github.com/pleo-io/centralized-templates/compare/v6.15.7...v6.16.0) (2022-02-28)


### Features

* **github-actions-ecr:** Add an optional start-redis step. ([#275](https://github.com/pleo-io/centralized-templates/issues/275)) ([93b4a80](https://github.com/pleo-io/centralized-templates/commit/93b4a8092afa542562f918a13eed684ff7692648))

## [6.15.7](https://github.com/pleo-io/centralized-templates/compare/v6.15.6...v6.15.7) (2022-02-25)


### Bug Fixes

* **github-build-ecr:** trigger release ([#281](https://github.com/pleo-io/centralized-templates/issues/281)) ([3beae5b](https://github.com/pleo-io/centralized-templates/commit/3beae5b8e1bf1f01fd856e64eea1c4979337229a))

## [6.15.6](https://github.com/pleo-io/centralized-templates/compare/v6.15.5...v6.15.6) (2022-02-18)


### Bug Fixes

* **ci:** Remove unnecessary DD_SERVICE ([#279](https://github.com/pleo-io/centralized-templates/issues/279)) ([c917509](https://github.com/pleo-io/centralized-templates/commit/c917509ed803707aba0b3e8ad3354b749fb79a44))

## [6.15.5](https://github.com/pleo-io/centralized-templates/compare/v6.15.4...v6.15.5) (2022-02-18)


### Bug Fixes

* **ci:** Start Datadog agent on demand to be able to push test results to Datadog ([9ab797c](https://github.com/pleo-io/centralized-templates/commit/9ab797c356444856519fe8a0858e596ddf06477d))

## [6.15.4](https://github.com/pleo-io/centralized-templates/compare/v6.15.3...v6.15.4) (2022-02-17)


### Bug Fixes

* **ci:** Remove service to run Datadog agent as service container ([#276](https://github.com/pleo-io/centralized-templates/issues/276)) ([17ff70c](https://github.com/pleo-io/centralized-templates/commit/17ff70c3ca74b4cf5d28c44f2465d3c2f29afd8c))

## [6.15.3](https://github.com/pleo-io/centralized-templates/compare/v6.15.2...v6.15.3) (2022-02-11)


### Bug Fixes

* **github-actions-ecr:** fix testcontainer tests flakiness increasing Docker's client.ping.timout ([#274](https://github.com/pleo-io/centralized-templates/issues/274)) ([cb8fd84](https://github.com/pleo-io/centralized-templates/commit/cb8fd848b1214e2ec7614d20218fa08787f05379))

## [6.15.2](https://github.com/pleo-io/centralized-templates/compare/v6.15.1...v6.15.2) (2022-02-08)


### Bug Fixes

* **build-kotlin-ecr:** fix skip-functests conditional check ([#273](https://github.com/pleo-io/centralized-templates/issues/273)) ([bd89ae1](https://github.com/pleo-io/centralized-templates/commit/bd89ae138ffa5ab84864ec4f65582f230302c607))

## [6.15.1](https://github.com/pleo-io/centralized-templates/compare/v6.15.0...v6.15.1) (2022-01-27)


### Bug Fixes

* **cicd:** Add workflow info in concurrency group identifier to allow different types of workflows to run concurrently on same branch ([#264](https://github.com/pleo-io/centralized-templates/issues/264)) ([9f7e548](https://github.com/pleo-io/centralized-templates/commit/9f7e548c7ee5d1e728f5ee7c4c9b866182eef95e))

# [6.15.0](https://github.com/pleo-io/centralized-templates/compare/v6.14.0...v6.15.0) (2022-01-27)


### Features

* **build-kotlin-ecr:** change publishing order and and task in node client ([#256](https://github.com/pleo-io/centralized-templates/issues/256)) ([8782c5c](https://github.com/pleo-io/centralized-templates/commit/8782c5c7b8ac174c42e203d8b3020bb0236fe6aa))

# [6.14.0](https://github.com/pleo-io/centralized-templates/compare/v6.13.1...v6.14.0) (2022-01-27)


### Features

* Remove Dependabot ([#261](https://github.com/pleo-io/centralized-templates/issues/261)) ([bc1b3b6](https://github.com/pleo-io/centralized-templates/commit/bc1b3b64aaa9b61663972072a3b9149aee1b816e))

## [6.13.1](https://github.com/pleo-io/centralized-templates/compare/v6.13.0...v6.13.1) (2022-01-27)


### Bug Fixes

* Remove Kodiak auto-approve for Renovate ([#262](https://github.com/pleo-io/centralized-templates/issues/262)) ([9837a9e](https://github.com/pleo-io/centralized-templates/commit/9837a9e8584b7887c6e5b22dfc47832972cf8e99))

# [6.13.0](https://github.com/pleo-io/centralized-templates/compare/v6.12.1...v6.13.0) (2022-01-27)


### Features

* **github-actions-ecr:** Allow bypass of functest when skip-functest label is applied. ([#260](https://github.com/pleo-io/centralized-templates/issues/260)) ([d2b6c4a](https://github.com/pleo-io/centralized-templates/commit/d2b6c4ae6a06e682d212b4fed1628fc583f5607d))

## [6.12.1](https://github.com/pleo-io/centralized-templates/compare/v6.12.0...v6.12.1) (2022-01-26)


### Reverts

* Revert "Feature/loki 1036 do not run func tests in main branch (#255)" (#259) ([28930dc](https://github.com/pleo-io/centralized-templates/commit/28930dceec3a626fab02760a6b14700695919319)), closes [#255](https://github.com/pleo-io/centralized-templates/issues/255) [#259](https://github.com/pleo-io/centralized-templates/issues/259)

# [6.12.0](https://github.com/pleo-io/centralized-templates/compare/v6.11.0...v6.12.0) (2022-01-25)


### Features

* **github-actions-ecr:** Trigger release because I'm dumb and forgot ([#254](https://github.com/pleo-io/centralized-templates/issues/254)) ([ce5659e](https://github.com/pleo-io/centralized-templates/commit/ce5659ee824c054c37606df3f45ed40fb20f9f43))

# [6.11.0](https://github.com/pleo-io/centralized-templates/compare/v6.10.0...v6.11.0) (2022-01-20)


### Features

* **github-actions-ecr:** Add optional datadog logging for tests ([#250](https://github.com/pleo-io/centralized-templates/issues/250)) ([fdee951](https://github.com/pleo-io/centralized-templates/commit/fdee951e066659aaaaca823ac72c000c8d3393d3))

# [6.10.0](https://github.com/pleo-io/centralized-templates/compare/v6.9.6...v6.10.0) (2022-01-20)


### Features

* **github-actions-virtualservice:** Release istio route validator. ([#249](https://github.com/pleo-io/centralized-templates/issues/249)) ([f47ad6c](https://github.com/pleo-io/centralized-templates/commit/f47ad6c2305751dc01cb0d8a80664a2384112fcb))

## [6.9.6](https://github.com/pleo-io/centralized-templates/compare/v6.9.5...v6.9.6) (2022-01-19)


### Bug Fixes

* **deps:** Revert unsplash/comment-on-pr GH action from 1.3.1 to 1.3.0 ([#245](https://github.com/pleo-io/centralized-templates/issues/245)) ([eb6f45a](https://github.com/pleo-io/centralized-templates/commit/eb6f45a4c6ce7c7ed75e75a92a8af26bd6641806))

## [6.9.5](https://github.com/pleo-io/centralized-templates/compare/v6.9.4...v6.9.5) (2022-01-14)


### Bug Fixes

* **build-kotlin-ecr:** fix typo in open api file ([#242](https://github.com/pleo-io/centralized-templates/issues/242)) ([8e54a5a](https://github.com/pleo-io/centralized-templates/commit/8e54a5add1059234576ccf61a99dac0a9062bf5f))

## [6.9.4](https://github.com/pleo-io/centralized-templates/compare/v6.9.3...v6.9.4) (2022-01-12)


### Bug Fixes

* **cicd:** Set correct folder yarn dependencies caching in CICD ([#241](https://github.com/pleo-io/centralized-templates/issues/241)) ([627e9de](https://github.com/pleo-io/centralized-templates/commit/627e9ded7efcbcde765d37513c05c71f46bd1361))

## [6.9.3](https://github.com/pleo-io/centralized-templates/compare/v6.9.2...v6.9.3) (2022-01-12)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 3.12.0 to 3.13.0 in /templates ([#238](https://github.com/pleo-io/centralized-templates/issues/238)) ([f9ac142](https://github.com/pleo-io/centralized-templates/commit/f9ac1426da71a24953ae7e1bc1134c14790b10de))
* **deps:** bump tj-actions/changed-files from 12 to 13.1 in /templates ([#239](https://github.com/pleo-io/centralized-templates/issues/239)) ([f10f43a](https://github.com/pleo-io/centralized-templates/commit/f10f43a26e04cf2e4ed08a6c2e99c99233a755a1))

## [6.9.2](https://github.com/pleo-io/centralized-templates/compare/v6.9.1...v6.9.2) (2022-01-10)


### Bug Fixes

* **deps:** bump unsplash/comment-on-pr from 1.3.0 to 1.3.1 in /templates ([#235](https://github.com/pleo-io/centralized-templates/issues/235)) ([c340146](https://github.com/pleo-io/centralized-templates/commit/c340146225c77ed687f02c0c33d21f0b2fc24975))

## [6.9.1](https://github.com/pleo-io/centralized-templates/compare/v6.9.0...v6.9.1) (2022-01-07)


### Bug Fixes

* **deps:** bump mikepenz/action-junit-report in /templates ([#237](https://github.com/pleo-io/centralized-templates/issues/237)) ([e4a5e68](https://github.com/pleo-io/centralized-templates/commit/e4a5e68fdf0c10bf7fedac3cde015448aaed329d))

# [6.9.0](https://github.com/pleo-io/centralized-templates/compare/v6.8.11...v6.9.0) (2022-01-06)


### Features

* Add condition for Kodiak automerging ([#232](https://github.com/pleo-io/centralized-templates/issues/232)) ([e1af0cf](https://github.com/pleo-io/centralized-templates/commit/e1af0cf53a7fdcbd5816bc4b1d9238d80ea82776))

## [6.8.10](https://github.com/pleo-io/centralized-templates/compare/v6.8.9...v6.8.10) (2022-01-04)


### Bug Fixes

* **deps:** bump actions/setup-node from 2.5.0 to 2.5.1 in /templates ([#227](https://github.com/pleo-io/centralized-templates/issues/227)) ([619d4bb](https://github.com/pleo-io/centralized-templates/commit/619d4bb049fb78475370924d95c5b42e278ad8a8))

## [6.8.9](https://github.com/pleo-io/centralized-templates/compare/v6.8.8...v6.8.9) (2021-12-29)


### Bug Fixes

* **deps:** bump actions/setup-java from 2.4.0 to 2.5.0 in /templates ([#221](https://github.com/pleo-io/centralized-templates/issues/221)) ([5ca4d32](https://github.com/pleo-io/centralized-templates/commit/5ca4d32ee5119507b021c09286f520e6070e3754))
* **deps:** bump mikepenz/action-junit-report in /templates ([#225](https://github.com/pleo-io/centralized-templates/issues/225)) ([064267f](https://github.com/pleo-io/centralized-templates/commit/064267f156ae66c238a007a6c70d004d5e7f6c99))

## [6.8.8](https://github.com/pleo-io/centralized-templates/compare/v6.8.7...v6.8.8) (2021-12-29)


### Bug Fixes

* **build-kotlin-ecr:** fix open api clients ([#226](https://github.com/pleo-io/centralized-templates/issues/226)) ([8360b82](https://github.com/pleo-io/centralized-templates/commit/8360b82ec86d1bfadd7b5e316b5d131b88db6fe9))

## [6.8.7](https://github.com/pleo-io/centralized-templates/compare/v6.8.6...v6.8.7) (2021-12-27)


### Bug Fixes

* **deps:** bump docker/login-action from 1.10.0 to 1.12.0 in /templates ([#220](https://github.com/pleo-io/centralized-templates/issues/220)) ([9111933](https://github.com/pleo-io/centralized-templates/commit/91119337a6a0a5647347f949bc190c9f5f28ef92))

## [6.8.6](https://github.com/pleo-io/centralized-templates/compare/v6.8.5...v6.8.6) (2021-12-22)


### Bug Fixes

* **build-kotlin-ecr:** trigger release ([#224](https://github.com/pleo-io/centralized-templates/issues/224)) ([6d55915](https://github.com/pleo-io/centralized-templates/commit/6d55915ea0f3804d7c40231e1fb0ba726a4681e9))

## [6.8.4](https://github.com/pleo-io/centralized-templates/compare/v6.8.3...v6.8.4) (2021-12-17)


### Bug Fixes

* **deps:** bump actions/upload-artifact in /templates ([#212](https://github.com/pleo-io/centralized-templates/issues/212)) ([d643009](https://github.com/pleo-io/centralized-templates/commit/d643009a4629b88f9fba8c4cfa85e418c042fa08))
* **deps:** bump tj-actions/changed-files from 11.9 to 12 in /templates ([#209](https://github.com/pleo-io/centralized-templates/issues/209)) ([8629db8](https://github.com/pleo-io/centralized-templates/commit/8629db801f7642a98a913071e74cda3d64cbdf70))

## [6.8.3](https://github.com/pleo-io/centralized-templates/compare/v6.8.2...v6.8.3) (2021-12-16)


### Bug Fixes

* **build_kotlin_ecr:** Fix comment because my other pr had two commits and thats terrible ([#216](https://github.com/pleo-io/centralized-templates/issues/216)) ([e39e97b](https://github.com/pleo-io/centralized-templates/commit/e39e97b8f539a06f2fa86aea53e01afb4e72c8ac))

## [6.8.2](https://github.com/pleo-io/centralized-templates/compare/v6.8.1...v6.8.2) (2021-12-16)


### Bug Fixes

* **build_kotlin_ecr:** All releaseOpenAPIClients tasks should only run in main. ([#214](https://github.com/pleo-io/centralized-templates/issues/214)) ([41278c5](https://github.com/pleo-io/centralized-templates/commit/41278c55d9dba28ea9f241ae09881b0b92330a32))

## [6.8.1](https://github.com/pleo-io/centralized-templates/compare/v6.8.0...v6.8.1) (2021-12-16)


### Bug Fixes

* **build-kotlin-ecr:** trigger release ([#211](https://github.com/pleo-io/centralized-templates/issues/211)) ([6263e10](https://github.com/pleo-io/centralized-templates/commit/6263e10bd90175f4ea9219cae2755759f8b75291))

# [6.8.0](https://github.com/pleo-io/centralized-templates/compare/v6.7.4...v6.8.0) (2021-12-10)


### Features

* **snyk:** move to separate workflow ([#186](https://github.com/pleo-io/centralized-templates/issues/186)) ([41b12fc](https://github.com/pleo-io/centralized-templates/commit/41b12fcf4197f4e9af9eb101151a5a56fdb10531))

## [6.7.4](https://github.com/pleo-io/centralized-templates/compare/v6.7.3...v6.7.4) (2021-12-09)


### Bug Fixes

* **deps:** bump actions/setup-java from 2.3.1 to 2.4.0 in /templates ([#199](https://github.com/pleo-io/centralized-templates/issues/199)) ([c2ba63b](https://github.com/pleo-io/centralized-templates/commit/c2ba63b10ac3155475a32e6b6d8088a4365e0d7b))
* **deps:** bump actions/setup-node from 2.4.1 to 2.5.0 in /templates ([#201](https://github.com/pleo-io/centralized-templates/issues/201)) ([47d707c](https://github.com/pleo-io/centralized-templates/commit/47d707c3e038f9c6de5c07bb3bf251c2775e8083))
* **deps:** bump actions/upload-artifact in /templates ([#203](https://github.com/pleo-io/centralized-templates/issues/203)) ([f2d37c9](https://github.com/pleo-io/centralized-templates/commit/f2d37c9e979b401094bd44c52747899ca1d12db3))
* **deps:** bump mikepenz/action-junit-report in /templates ([#200](https://github.com/pleo-io/centralized-templates/issues/200)) ([0d8d01e](https://github.com/pleo-io/centralized-templates/commit/0d8d01e9901c4275e1b920a39559d6116b469ffc))
* **deps:** bump pleo-io/actions from 13.0.0 to 14.3.3 in /templates ([#204](https://github.com/pleo-io/centralized-templates/issues/204)) ([ad60a98](https://github.com/pleo-io/centralized-templates/commit/ad60a986c76dbec5eda7343a53ed9c9ba4a5642e))

## [6.7.3](https://github.com/pleo-io/centralized-templates/compare/v6.7.2...v6.7.3) (2021-11-26)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 3.11.0 to 3.12.0 in /templates ([#194](https://github.com/pleo-io/centralized-templates/issues/194)) ([c717023](https://github.com/pleo-io/centralized-templates/commit/c7170238e4c27469cad36c75edc8f90c03c6e7f8))
* **deps:** bump aws-actions/configure-aws-credentials in /templates ([#195](https://github.com/pleo-io/centralized-templates/issues/195)) ([c797854](https://github.com/pleo-io/centralized-templates/commit/c797854f9a65daa7630a63064a54ee88d47688b2))
* **deps:** bump mikepenz/action-junit-report in /templates ([#191](https://github.com/pleo-io/centralized-templates/issues/191)) ([8107eb0](https://github.com/pleo-io/centralized-templates/commit/8107eb0582e4e92db61bf80e4cbd05e7f44a0bb4))
* **deps:** bump webfactory/ssh-agent from 0.5.3 to 0.5.4 in /templates ([#192](https://github.com/pleo-io/centralized-templates/issues/192)) ([281acaf](https://github.com/pleo-io/centralized-templates/commit/281acaf0558ce3a8da5d41ab58f7beb14c8c93f3))

## [6.7.2](https://github.com/pleo-io/centralized-templates/compare/v6.7.1...v6.7.2) (2021-11-22)


### Bug Fixes

* **cicd:** limit job concurrency ([#193](https://github.com/pleo-io/centralized-templates/issues/193)) ([14ee843](https://github.com/pleo-io/centralized-templates/commit/14ee84349ba702ded865e5ac4389df6a6ff013d8))

## [6.7.1](https://github.com/pleo-io/centralized-templates/compare/v6.7.0...v6.7.1) (2021-11-18)


### Bug Fixes

* **cicd:** use v13.0.0 instead of 13.0.0 ([#189](https://github.com/pleo-io/centralized-templates/issues/189)) ([0b78cbd](https://github.com/pleo-io/centralized-templates/commit/0b78cbda0339c16cd197dc37161b4981c43e120a))

# [6.7.0](https://github.com/pleo-io/centralized-templates/compare/v6.6.2...v6.7.0) (2021-11-18)


### Features

* **cicd:** support database migration as a job + fix passing commit SHA between workflows ([#188](https://github.com/pleo-io/centralized-templates/issues/188)) ([8de1c2f](https://github.com/pleo-io/centralized-templates/commit/8de1c2f20b2c18ae6e8abb35403ce18f6c1e2a8d))

## [6.6.2](https://github.com/pleo-io/centralized-templates/compare/v6.6.1...v6.6.2) (2021-11-17)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 3.10.0 to 3.11.0 in /templates ([#185](https://github.com/pleo-io/centralized-templates/issues/185)) ([a1cdd34](https://github.com/pleo-io/centralized-templates/commit/a1cdd340c6e7cf05644bdc9cdbea81a953c87fcd))

## [6.6.1](https://github.com/pleo-io/centralized-templates/compare/v6.6.0...v6.6.1) (2021-11-15)


### Bug Fixes

* **publish_libaray_typescript:** Bump to node 16 to match manual changes in workflow file ([#184](https://github.com/pleo-io/centralized-templates/issues/184)) ([91f044b](https://github.com/pleo-io/centralized-templates/commit/91f044bb1f239de8efe0aa5351dfe8652a29d76d))

# [6.6.0](https://github.com/pleo-io/centralized-templates/compare/v6.5.5...v6.6.0) (2021-11-10)


### Features

* **k8s_deploy_*:** provide relevant logs for current deployment ([#183](https://github.com/pleo-io/centralized-templates/issues/183)) ([81bc750](https://github.com/pleo-io/centralized-templates/commit/81bc75059158d9b0cf78053746b4905e343280af))

## [6.5.5](https://github.com/pleo-io/centralized-templates/compare/v6.5.4...v6.5.5) (2021-11-10)


### Bug Fixes

* **deps:** bump pleo-io/actions from 12.1.0 to 12.2.0 in /templates ([#179](https://github.com/pleo-io/centralized-templates/issues/179)) ([9f66316](https://github.com/pleo-io/centralized-templates/commit/9f663161ef1bf8dd95c70bbdeb54e5dbf16df3fa))

## [6.5.4](https://github.com/pleo-io/centralized-templates/compare/v6.5.3...v6.5.4) (2021-11-08)


### Bug Fixes

* **deps:** bump mikepenz/action-junit-report from 2.5.1 to 2.7.0 in /templates ([#181](https://github.com/pleo-io/centralized-templates/issues/181)) ([4c87a83](https://github.com/pleo-io/centralized-templates/commit/4c87a838320b42e264328886659ab66a90f9b893))

## [6.5.3](https://github.com/pleo-io/centralized-templates/compare/v6.5.2...v6.5.3) (2021-11-08)


### Bug Fixes

* **cicd:** Set redisRequired as optional step ([#180](https://github.com/pleo-io/centralized-templates/issues/180)) ([f23cc2d](https://github.com/pleo-io/centralized-templates/commit/f23cc2de3c3283301ba6c8383d8db736f188b98f))

## [6.5.2](https://github.com/pleo-io/centralized-templates/compare/v6.5.1...v6.5.2) (2021-11-04)


### Bug Fixes

* **deps:** bump pleo-io/actions from 12.0.2 to 12.1.0 in /templates ([#177](https://github.com/pleo-io/centralized-templates/issues/177)) ([92b3466](https://github.com/pleo-io/centralized-templates/commit/92b34665fa7214fc35cbdf203706d5471445b913))

## [6.5.1](https://github.com/pleo-io/centralized-templates/compare/v6.5.0...v6.5.1) (2021-11-04)


### Bug Fixes

* **deps:** bump actions/checkout from 2.3.5 to 2.4.0 in /templates ([#178](https://github.com/pleo-io/centralized-templates/issues/178)) ([f5f587a](https://github.com/pleo-io/centralized-templates/commit/f5f587a7a6d74dd80937e2bfaabd11860fa3af3e))

# [6.5.0](https://github.com/pleo-io/centralized-templates/compare/v6.4.1...v6.5.0) (2021-11-03)


### Features

* **github-actions-ecr:** Add a conditional Release Kotlin Client job ([#175](https://github.com/pleo-io/centralized-templates/issues/175)) ([1dc88af](https://github.com/pleo-io/centralized-templates/commit/1dc88af94587b7a5b44641c660e56de0f0341b1c))

## [6.4.1](https://github.com/pleo-io/centralized-templates/compare/v6.4.0...v6.4.1) (2021-11-02)


### Bug Fixes

* **deps:** bump actions/checkout from 2.3.4 to 2.3.5 in /templates ([#174](https://github.com/pleo-io/centralized-templates/issues/174)) ([43def90](https://github.com/pleo-io/centralized-templates/commit/43def900ac404908f046c182e967b3030a57c619))

# [6.4.0](https://github.com/pleo-io/centralized-templates/compare/v6.3.9...v6.4.0) (2021-11-01)


### Features

* **virtualservice:** new virtualservice template ([#171](https://github.com/pleo-io/centralized-templates/issues/171)) ([7f2ac54](https://github.com/pleo-io/centralized-templates/commit/7f2ac54fcc90e6be3aa6e2ca913d125b171f6bc7))

## [6.3.9](https://github.com/pleo-io/centralized-templates/compare/v6.3.8...v6.3.9) (2021-10-27)


### Bug Fixes

* **deps:** bump pleo-io/actions from 12.0.1 to 12.0.2 in /templates ([#172](https://github.com/pleo-io/centralized-templates/issues/172)) ([d29309e](https://github.com/pleo-io/centralized-templates/commit/d29309e37f18eab0bb3a020d94e649d7bbf052a5))

## [6.3.8](https://github.com/pleo-io/centralized-templates/compare/v6.3.7...v6.3.8) (2021-10-22)


### Bug Fixes

* **cicd:** Use built-in dependencies caching in setup-node and setup-java actions([#169](https://github.com/pleo-io/centralized-templates/issues/169)) ([2d6f32a](https://github.com/pleo-io/centralized-templates/commit/2d6f32a904a7842be1f19190a9596079bff9979b))

## [6.3.7](https://github.com/pleo-io/centralized-templates/compare/v6.3.6...v6.3.7) (2021-10-22)


### Bug Fixes

* **deps:** bump pleo-io/actions from 11.1.0 to 12.0.1 in /templates ([#168](https://github.com/pleo-io/centralized-templates/issues/168)) ([ecc17cb](https://github.com/pleo-io/centralized-templates/commit/ecc17cbdfe934aeb2f91c2a324bfb691c324b0bf))

## [6.3.6](https://github.com/pleo-io/centralized-templates/compare/v6.3.5...v6.3.6) (2021-10-22)


### Bug Fixes

* **deps:** bump actions/checkout from 2.3.4 to 2.3.5 in /templates ([#167](https://github.com/pleo-io/centralized-templates/issues/167)) ([b16c082](https://github.com/pleo-io/centralized-templates/commit/b16c082b607aedcd540af60c0c36f643db9853b7))

## [6.3.5](https://github.com/pleo-io/centralized-templates/compare/v6.3.4...v6.3.5) (2021-10-19)


### Bug Fixes

* **deps:** bump actions/setup-java from 2.3.0 to 2.3.1 in /templates ([#156](https://github.com/pleo-io/centralized-templates/issues/156)) ([87a7f73](https://github.com/pleo-io/centralized-templates/commit/87a7f730fc34daa0ace4488d65af71ba5165c8da))
* **deps:** bump actions/setup-node from 2.4.0 to 2.4.1 in /templates ([#153](https://github.com/pleo-io/centralized-templates/issues/153)) ([4cf24bc](https://github.com/pleo-io/centralized-templates/commit/4cf24bcc167b5cc0a75abe019f2aa62ae3759baa))
* **deps:** bump mikepenz/action-junit-report in /templates ([#164](https://github.com/pleo-io/centralized-templates/issues/164)) ([6de0309](https://github.com/pleo-io/centralized-templates/commit/6de0309e48aa013c9b9d34f410deab36d9d3271f))
* **deps:** bump testspace-com/setup-testspace in /templates ([#162](https://github.com/pleo-io/centralized-templates/issues/162)) ([87ebe32](https://github.com/pleo-io/centralized-templates/commit/87ebe32994ac56cbd991a240d42e81ef2b662eb1))

## [6.3.4](https://github.com/pleo-io/centralized-templates/compare/v6.3.3...v6.3.4) (2021-10-19)


### Bug Fixes

* **deps:** bump pleo-io/actions from 10.1.1 to 11.1.0 in /templates ([#163](https://github.com/pleo-io/centralized-templates/issues/163)) ([5f0056e](https://github.com/pleo-io/centralized-templates/commit/5f0056ed4cf001d66adaf0400f15b0fc541670c4))

## [6.3.3](https://github.com/pleo-io/centralized-templates/compare/v6.3.2...v6.3.3) (2021-10-07)


### Bug Fixes

* **github-actions-ecr:** continue on error for jacoco agg report generation ([#161](https://github.com/pleo-io/centralized-templates/issues/161)) ([9c793b5](https://github.com/pleo-io/centralized-templates/commit/9c793b57536d8c5c26d8bff237944e02b3cb4eb3))

## [6.3.2](https://github.com/pleo-io/centralized-templates/compare/v6.3.1...v6.3.2) (2021-10-06)


### Bug Fixes

* **deps:** bump mikepenz/action-junit-report in /templates ([#160](https://github.com/pleo-io/centralized-templates/issues/160)) ([a7cb2f8](https://github.com/pleo-io/centralized-templates/commit/a7cb2f856dc75c12acbcf68cebdd39c6f0d05af8))

## [6.3.1](https://github.com/pleo-io/centralized-templates/compare/v6.3.0...v6.3.1) (2021-10-06)


### Bug Fixes

* **deps:** bump unsplash/comment-on-pr from 1.2.0 to 1.3.0 in /templates ([#159](https://github.com/pleo-io/centralized-templates/issues/159)) ([867589b](https://github.com/pleo-io/centralized-templates/commit/867589b17f20a5e7807bbc63ec40d58c58cc8396))

# [6.3.0](https://github.com/pleo-io/centralized-templates/compare/v6.2.8...v6.3.0) (2021-10-04)


### Features

* **github-actions-ecr:** Do not run snyk on main branch ([#150](https://github.com/pleo-io/centralized-templates/issues/150)) ([23dfc64](https://github.com/pleo-io/centralized-templates/commit/23dfc6460522222037e9c124513c8940058db0c7))

## [6.2.8](https://github.com/pleo-io/centralized-templates/compare/v6.2.7...v6.2.8) (2021-09-30)


### Bug Fixes

* **k8s_deploy:** Remove logging step ([#157](https://github.com/pleo-io/centralized-templates/issues/157)) ([3500803](https://github.com/pleo-io/centralized-templates/commit/350080324e8f89608ad4e0a743e0af953f62bf7a))

## [6.2.7](https://github.com/pleo-io/centralized-templates/compare/v6.2.6...v6.2.7) (2021-09-28)


### Bug Fixes

* **cicd:** Add Gradle registry token to Snyk CICD step ([#154](https://github.com/pleo-io/centralized-templates/issues/154)) ([a7bf9f9](https://github.com/pleo-io/centralized-templates/commit/a7bf9f94a45fdd68478bd250a8957fe162ec3e49))

## [6.2.6](https://github.com/pleo-io/centralized-templates/compare/v6.2.5...v6.2.6) (2021-09-27)


### Bug Fixes

* **deploy_k8s:** Fix deploy logs ([#151](https://github.com/pleo-io/centralized-templates/issues/151)) ([4f4ae03](https://github.com/pleo-io/centralized-templates/commit/4f4ae034405b1bc0ab423b5660e66689a1263034))

## [6.2.5](https://github.com/pleo-io/centralized-templates/compare/v6.2.4...v6.2.5) (2021-09-22)


### Bug Fixes

* **k8s_deploy_*:** Add better logging to failed CICD deployments ([#148](https://github.com/pleo-io/centralized-templates/issues/148)) ([2ea8e78](https://github.com/pleo-io/centralized-templates/commit/2ea8e78bdaed0c0b33710dba2788e4bc6e1c50be))

## [6.2.4](https://github.com/pleo-io/centralized-templates/compare/v6.2.3...v6.2.4) (2021-09-21)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 3.9.3 to 3.10.0 in /templates ([#149](https://github.com/pleo-io/centralized-templates/issues/149)) ([ec4e4ee](https://github.com/pleo-io/centralized-templates/commit/ec4e4ee49e433855c389aeecd87f39be43b3ddda))

## [6.2.3](https://github.com/pleo-io/centralized-templates/compare/v6.2.2...v6.2.3) (2021-09-15)


### Bug Fixes

* **github-actions-ecr:** release to run snyk before gradle build ([#147](https://github.com/pleo-io/centralized-templates/issues/147)) ([26baf81](https://github.com/pleo-io/centralized-templates/commit/26baf81277a9dfa8ab89fe60c78dc01ed3ae4485))

## [6.2.2](https://github.com/pleo-io/centralized-templates/compare/v6.2.1...v6.2.2) (2021-09-14)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 3.9.2 to 3.9.3 in /templates ([#142](https://github.com/pleo-io/centralized-templates/issues/142)) ([e639146](https://github.com/pleo-io/centralized-templates/commit/e6391469258de9c5aaae315c9d1c93f530e14d22))
* **deps:** bump actions/setup-java from 2.2.0 to 2.3.0 in /templates ([#138](https://github.com/pleo-io/centralized-templates/issues/138)) ([39f8fde](https://github.com/pleo-io/centralized-templates/commit/39f8fde99c7d89fde867bda35b11ddb986fa8b0b))

## [6.2.1](https://github.com/pleo-io/centralized-templates/compare/v6.2.0...v6.2.1) (2021-09-14)


### Bug Fixes

* **trigger-workflow-dispatch:** update version ([#145](https://github.com/pleo-io/centralized-templates/issues/145)) ([5349ee0](https://github.com/pleo-io/centralized-templates/commit/5349ee0be97f5e6ad920f20317743689b89d53a7))

# [6.2.0](https://github.com/pleo-io/centralized-templates/compare/v6.1.0...v6.2.0) (2021-09-14)


### Features

* **github-actions:** remove kustomize docker ([#143](https://github.com/pleo-io/centralized-templates/issues/143)) ([367f13f](https://github.com/pleo-io/centralized-templates/commit/367f13f5a8351a33401e2d17c7182a1f8286ed7b))

# [6.1.0](https://github.com/pleo-io/centralized-templates/compare/v6.0.12...v6.1.0) (2021-09-13)


### Features

* **github-actions:** Docker login on workflow ([#141](https://github.com/pleo-io/centralized-templates/issues/141)) ([29cf02d](https://github.com/pleo-io/centralized-templates/commit/29cf02d794c386ba773a9c497572f1962f18aba2))

## [6.0.12](https://github.com/pleo-io/centralized-templates/compare/v6.0.11...v6.0.12) (2021-09-13)


### Bug Fixes

* **deps:** bump mikepenz/action-junit-report in /templates ([#139](https://github.com/pleo-io/centralized-templates/issues/139)) ([cf13623](https://github.com/pleo-io/centralized-templates/commit/cf13623d2b18d20f9aa350b8114ce2ffc883b16b))

## [6.0.11](https://github.com/pleo-io/centralized-templates/compare/v6.0.10...v6.0.11) (2021-08-20)


### Bug Fixes

* **deps:** bump pleo-io/actions from 10.0.0 to 10.1.0 in /templates ([#137](https://github.com/pleo-io/centralized-templates/issues/137)) ([fa7f9f3](https://github.com/pleo-io/centralized-templates/commit/fa7f9f3b4838be5d87caef87d792380419fe5de4))

## [6.0.10](https://github.com/pleo-io/centralized-templates/compare/v6.0.9...v6.0.10) (2021-08-18)


### Bug Fixes

* **deps:** bump pleo-io/actions from 9.4 to 10.0.0 in /templates ([#136](https://github.com/pleo-io/centralized-templates/issues/136)) ([e3052f5](https://github.com/pleo-io/centralized-templates/commit/e3052f517d0b26ba31edd7264138d1f7794eca37))

## [6.0.9](https://github.com/pleo-io/centralized-templates/compare/v6.0.8...v6.0.9) (2021-08-17)


### Bug Fixes

* **deps:** bump actions/setup-java from 2.1.0 to 2.2.0 in /templates ([#132](https://github.com/pleo-io/centralized-templates/issues/132)) ([46474eb](https://github.com/pleo-io/centralized-templates/commit/46474ebe6d85e21350ef389d67227a5592be39e7))

## [6.0.8](https://github.com/pleo-io/centralized-templates/compare/v6.0.7...v6.0.8) (2021-08-13)


### Bug Fixes

* **workflow ci:** Improved Slack alerts for deploy failures ([dca7ed6](https://github.com/pleo-io/centralized-templates/commit/dca7ed622b42b67ae4242fb6b3b001a2df53807c))

## [6.0.7](https://github.com/pleo-io/centralized-templates/compare/v6.0.6...v6.0.7) (2021-08-12)


### Bug Fixes

* **deps:** bump pleo-io/actions from 9.3 to 9.4 in /templates ([#133](https://github.com/pleo-io/centralized-templates/issues/133)) ([301c7db](https://github.com/pleo-io/centralized-templates/commit/301c7dbd3a3e2f49663cfff81402bfb33d09ea6a))

## [6.0.6](https://github.com/pleo-io/centralized-templates/compare/v6.0.5...v6.0.6) (2021-08-09)


### Bug Fixes

* **deps:** bump actions/setup-node from 2.3.1 to 2.3.2 in /templates ([#130](https://github.com/pleo-io/centralized-templates/issues/130)) ([7d09514](https://github.com/pleo-io/centralized-templates/commit/7d0951459ec64ea3630a5322cdc08caaedbe3632))
* **deps:** bump actions/setup-node from 2.3.2 to 2.4.0 in /templates ([#131](https://github.com/pleo-io/centralized-templates/issues/131)) ([74faf30](https://github.com/pleo-io/centralized-templates/commit/74faf3081998d352f6ae63ceb89e2bb3b337d463))

## [6.0.5](https://github.com/pleo-io/centralized-templates/compare/v6.0.4...v6.0.5) (2021-08-04)


### Bug Fixes

* **deps:** bump actions/setup-node from 2.3.0 to 2.3.1 in /templates ([#129](https://github.com/pleo-io/centralized-templates/issues/129)) ([6321ede](https://github.com/pleo-io/centralized-templates/commit/6321ede8e675486c2e9b4006ce0e530f46f2c6a0))

## [6.0.4](https://github.com/pleo-io/centralized-templates/compare/v6.0.3...v6.0.4) (2021-08-03)


### Bug Fixes

* **deps:** bump 8398a7/action-slack from 2.7.0 to 3.9.2 in /templates ([#126](https://github.com/pleo-io/centralized-templates/issues/126)) ([c050f7a](https://github.com/pleo-io/centralized-templates/commit/c050f7aded7c5828db49c35918d01e7bc44c7660))

## [6.0.3](https://github.com/pleo-io/centralized-templates/compare/v6.0.2...v6.0.3) (2021-07-30)


### Bug Fixes

* **templates:** fix build_kotlin file ([#128](https://github.com/pleo-io/centralized-templates/issues/128)) ([87d390c](https://github.com/pleo-io/centralized-templates/commit/87d390cefc2aeac4816c3d4f7866f709702cf59a))

## [6.0.2](https://github.com/pleo-io/centralized-templates/compare/v6.0.1...v6.0.2) (2021-07-30)


### Bug Fixes

* **deps:** bump mikepenz/action-junit-report in /templates ([#127](https://github.com/pleo-io/centralized-templates/issues/127)) ([f316395](https://github.com/pleo-io/centralized-templates/commit/f316395232ab25e463f16130c11f360832634fa1))
* **deps:** bump styfle/cancel-workflow-action in /templates ([#125](https://github.com/pleo-io/centralized-templates/issues/125)) ([90092c6](https://github.com/pleo-io/centralized-templates/commit/90092c65ca9a98208e455b8a635699e0cd181095))
* **deps:** bump webfactory/ssh-agent from 0.5.2 to 0.5.3 in /templates ([#124](https://github.com/pleo-io/centralized-templates/issues/124)) ([6f05e6b](https://github.com/pleo-io/centralized-templates/commit/6f05e6bd4c19bd84af17389ab62d9418f66e9c7c))

## [6.0.1](https://github.com/pleo-io/centralized-templates/compare/v6.0.0...v6.0.1) (2021-07-30)


### Bug Fixes

* **formatting:** fix yaml formatting ([#123](https://github.com/pleo-io/centralized-templates/issues/123)) ([37b6576](https://github.com/pleo-io/centralized-templates/commit/37b6576241ed3991f9930f07227ec51aa7104fdf))

# [6.0.0](https://github.com/pleo-io/centralized-templates/compare/v5.6.2...v6.0.0) (2021-07-30)


### Code Refactoring

* **prefix templates with ##:** make templates dependabot compatible ([#121](https://github.com/pleo-io/centralized-templates/issues/121)) ([7ca4bdc](https://github.com/pleo-io/centralized-templates/commit/7ca4bdc8d23fdadf5ed34fb3548b58f1b90c1ecc))


### BREAKING CHANGES

* **prefix templates with ##:** new format of templates

* update README

## [5.6.2](https://github.com/pleo-io/centralized-templates/compare/v5.6.1...v5.6.2) (2021-07-30)


### Bug Fixes

* **docker-build:** always include build-arg github_sha ([#122](https://github.com/pleo-io/centralized-templates/issues/122)) ([c5241df](https://github.com/pleo-io/centralized-templates/commit/c5241df55bf6fe48827f7533c1e571053163fd5b))

## [5.6.1](https://github.com/pleo-io/centralized-templates/compare/v5.6.0...v5.6.1) (2021-07-29)


### Bug Fixes

* **publish_library_typescript:** set `fetch-depth: 0` ([#120](https://github.com/pleo-io/centralized-templates/issues/120)) ([5a27bad](https://github.com/pleo-io/centralized-templates/commit/5a27badd957efe5f3bac4b7b9b3cc6402b099400)), closes [/github.com/pleo-io/centralized-templates/pull/102/files#r648174102](https://github.com//github.com/pleo-io/centralized-templates/pull/102/files/issues/r648174102) [/github.com/pleo-io/deimos/commit/3cb1928a5d26657e9f96e038400be7131f2c8987#diff-23f559fcc818416713f3ff657a94d013066d82e22d066bd0cfab5bf7b6af0eb1L47](https://github.com//github.com/pleo-io/deimos/commit/3cb1928a5d26657e9f96e038400be7131f2c8987/issues/diff-23f559fcc818416713f3ff657a94d013066d82e22d066bd0cfab5bf7b6af0eb1L47)

# [5.6.0](https://github.com/pleo-io/centralized-templates/compare/v5.5.0...v5.6.0) (2021-07-27)


### Features

* **runnerEnviroment:** explicitly set all workflows on self-hosted universal ([#119](https://github.com/pleo-io/centralized-templates/issues/119)) ([54fd88f](https://github.com/pleo-io/centralized-templates/commit/54fd88f438dc2d3797296393dc1cffefe6276d0d))

# [5.5.0](https://github.com/pleo-io/centralized-templates/compare/v5.4.2...v5.5.0) (2021-07-27)


### Features

* **dependabot.yml:** Add dependatbot.yml file ([#118](https://github.com/pleo-io/centralized-templates/issues/118)) ([5fd7962](https://github.com/pleo-io/centralized-templates/commit/5fd7962b2d4245a43138c2ec1b0783fe7599dac7))

## [5.4.2](https://github.com/pleo-io/centralized-templates/compare/v5.4.1...v5.4.2) (2021-07-22)


### Bug Fixes

* **update deps:** Bump setup-node GH action to 2.3.0 ([#117](https://github.com/pleo-io/centralized-templates/issues/117)) ([e31bbb7](https://github.com/pleo-io/centralized-templates/commit/e31bbb72cac830e81f837b32afdc8643adc03180))

## [5.4.1](https://github.com/pleo-io/centralized-templates/compare/v5.4.0...v5.4.1) (2021-07-16)


### Bug Fixes

* **snyk-subproject:** Setting snyk test and monitor for all subproject argument ([#114](https://github.com/pleo-io/centralized-templates/issues/114)) ([18a4191](https://github.com/pleo-io/centralized-templates/commit/18a4191fc7e9e73abda0f840424108dbc99fd386))

# [5.4.0](https://github.com/pleo-io/centralized-templates/compare/v5.3.0...v5.4.0) (2021-07-14)


### Features

* **funcTestEnabled:** Adding conditional logic to allow skipping functests ([#113](https://github.com/pleo-io/centralized-templates/issues/113)) ([fa51825](https://github.com/pleo-io/centralized-templates/commit/fa51825361d33cc585cdfcf59e3d0972ee704b6b))

# [5.3.0](https://github.com/pleo-io/centralized-templates/compare/v5.2.0...v5.3.0) (2021-07-07)


### Features

* **all-templates:** Add runnerEnviroment for conditional enablement of self-hosted ([#111](https://github.com/pleo-io/centralized-templates/issues/111)) ([96f5f8c](https://github.com/pleo-io/centralized-templates/commit/96f5f8ccfc78007d64a9f0cf0ef5b31d344fbf7e))

# [5.2.0](https://github.com/pleo-io/centralized-templates/compare/v5.1.17...v5.2.0) (2021-07-07)


### Features

* **deploy_k8s_primary.yaml:** remove not used file ([#110](https://github.com/pleo-io/centralized-templates/issues/110)) ([ed4cb9e](https://github.com/pleo-io/centralized-templates/commit/ed4cb9e33535431df5909ad553444225742448f2))

## [5.1.17](https://github.com/pleo-io/centralized-templates/compare/v5.1.16...v5.1.17) (2021-07-05)


### Bug Fixes

* **deploy_k8s_feature_typescript:** make ecr compatible ([#109](https://github.com/pleo-io/centralized-templates/issues/109)) ([0aa71f5](https://github.com/pleo-io/centralized-templates/commit/0aa71f5e68ce57a83a6d9d36d134c46eb1fa910e))

## [5.1.16](https://github.com/pleo-io/centralized-templates/compare/v5.1.15...v5.1.16) (2021-07-05)


### Bug Fixes

* **publish_library_typescript:** add yarn release to Auto release step ([#108](https://github.com/pleo-io/centralized-templates/issues/108)) ([b3cbf50](https://github.com/pleo-io/centralized-templates/commit/b3cbf5022858a525392ea9e793aa15c7f149715d))

## [5.1.15](https://github.com/pleo-io/centralized-templates/compare/v5.1.14...v5.1.15) (2021-07-05)


### Bug Fixes

* **publish_library_typescript:** use only yarn build to release ([#107](https://github.com/pleo-io/centralized-templates/issues/107)) ([898d3c1](https://github.com/pleo-io/centralized-templates/commit/898d3c100700b05e4e4d978654ddeca98d28b5d3))

## [5.1.14](https://github.com/pleo-io/centralized-templates/compare/v5.1.13...v5.1.14) (2021-06-17)


### Bug Fixes

* **dependencies:** Bump actions/upload-artifact from 2.2.3 to 2.2.4 ([#106](https://github.com/pleo-io/centralized-templates/issues/106)) ([dc64515](https://github.com/pleo-io/centralized-templates/commit/dc64515734204a6f724798a5aa5b63b805126bf3))

## [5.1.13](https://github.com/pleo-io/centralized-templates/compare/v5.1.12...v5.1.13) (2021-06-09)


### Bug Fixes

* **ci workflow:** Remove explicit usage of fetch-depth ([#102](https://github.com/pleo-io/centralized-templates/issues/102)) ([274feee](https://github.com/pleo-io/centralized-templates/commit/274feeeedf49f405da3372f7e6d1ccb9d076eeba))

## [5.1.12](https://github.com/pleo-io/centralized-templates/compare/v5.1.11...v5.1.12) (2021-06-08)


### Bug Fixes

* **update deps:** Bump aws-actions/configure-aws-credentials to v1.5.10 ([#101](https://github.com/pleo-io/centralized-templates/issues/101)) ([e2bf227](https://github.com/pleo-io/centralized-templates/commit/e2bf2275f05e6a534236d80bda48e0275c61b660))

## [5.1.11](https://github.com/pleo-io/centralized-templates/compare/v5.1.10...v5.1.11) (2021-06-08)


### Bug Fixes

* **update deps:** Bump action-slack-notify to 2.2.0 ([#100](https://github.com/pleo-io/centralized-templates/issues/100)) ([bb926f2](https://github.com/pleo-io/centralized-templates/commit/bb926f2700b7087ec0df08c7597a192eb16b7703))

## [5.1.10](https://github.com/pleo-io/centralized-templates/compare/v5.1.9...v5.1.10) (2021-06-01)


### Bug Fixes

* **Update dependencies:** Bump action-junit-report to 2.4.2 and actions/cache to 2.1.6 ([5d1269d](https://github.com/pleo-io/centralized-templates/commit/5d1269dd26647c02c4c2f8a263dfa9c96815b85d))

## [5.1.9](https://github.com/pleo-io/centralized-templates/compare/v5.1.8...v5.1.9) (2021-05-28)


### Bug Fixes

* **ci workflow:** Use explicit OS version for GH actions runner ([#98](https://github.com/pleo-io/centralized-templates/issues/98)) ([377078d](https://github.com/pleo-io/centralized-templates/commit/377078d8602df928a0217781ed7ae8bb70e8a2ee))

## [5.1.8](https://github.com/pleo-io/centralized-templates/compare/v5.1.7...v5.1.8) (2021-05-20)


### Bug Fixes

* **publish_library_typescript:** adds permissions to GITHUB_TOKEN to cancel previous workflows ([#97](https://github.com/pleo-io/centralized-templates/issues/97)) ([2e30e17](https://github.com/pleo-io/centralized-templates/commit/2e30e17df8e0b323ab31bf08a2c51fbfea2a06f9))

## [5.1.7](https://github.com/pleo-io/centralized-templates/compare/v5.1.6...v5.1.7) (2021-05-19)


### Bug Fixes

* **dependencies:** Use explicit versions for GH actions ([#96](https://github.com/pleo-io/centralized-templates/issues/96)) ([04de957](https://github.com/pleo-io/centralized-templates/commit/04de95761f53e2992c467ecc048effb09041346b))

## [5.1.6](https://github.com/pleo-io/centralized-templates/compare/v5.1.5...v5.1.6) (2021-05-19)


### Bug Fixes

* **ci workflow:** Remove obsolete need to fetch-depth 50 for Testspace ([#95](https://github.com/pleo-io/centralized-templates/issues/95)) ([7475f02](https://github.com/pleo-io/centralized-templates/commit/7475f02bf0be38124354273015425186ec8101a3))

## [5.1.5](https://github.com/pleo-io/centralized-templates/compare/v5.1.4...v5.1.5) (2021-05-19)


### Bug Fixes

* **publish_library_typescript:** fix typo in file ([#94](https://github.com/pleo-io/centralized-templates/issues/94)) ([58880e2](https://github.com/pleo-io/centralized-templates/commit/58880e2f81b854e39a9d57ac17ca4bd15c72b264))

## [5.1.4](https://github.com/pleo-io/centralized-templates/compare/v5.1.3...v5.1.4) (2021-05-19)


### Bug Fixes

* **publish_library_typescript:** Move file to workflow directory ([#93](https://github.com/pleo-io/centralized-templates/issues/93)) ([565a4b8](https://github.com/pleo-io/centralized-templates/commit/565a4b8db2fe76ec808d41fe6d7d606e646be8fa))

## [5.1.3](https://github.com/pleo-io/centralized-templates/compare/v5.1.2...v5.1.3) (2021-05-19)


### Bug Fixes

* add back accidentally deleted workflow for publishing ts contracts ([#92](https://github.com/pleo-io/centralized-templates/issues/92)) ([a0fa95a](https://github.com/pleo-io/centralized-templates/commit/a0fa95a1faa1569dd23db9a9c47b27db8e1a2a43))

## [5.1.2](https://github.com/pleo-io/github-actions-centralization/compare/v5.1.1...v5.1.2) (2021-05-17)


### Bug Fixes

* **fh workflows:** Bump mikepenz/action-junit-report GH action to 2.4.1 ([#85](https://github.com/pleo-io/github-actions-centralization/issues/85)) ([5d9e9bc](https://github.com/pleo-io/github-actions-centralization/commit/5d9e9bcf4a3b08c34bcbca05442a0cf0a40406e0))

## [5.1.1](https://github.com/pleo-io/github-actions-centralization/compare/v5.1.0...v5.1.1) (2021-05-17)


### Bug Fixes

* **gh-workflows:** remove new lines from if statements ([#90](https://github.com/pleo-io/github-actions-centralization/issues/90)) ([6644a4f](https://github.com/pleo-io/github-actions-centralization/commit/6644a4f2059561bee92e97588e1117ce7d6de214))

# [5.1.0](https://github.com/pleo-io/github-actions-centralization/compare/v5.0.3...v5.1.0) (2021-05-17)


### Features

* **gh-workflows:** support TestSpace ([#89](https://github.com/pleo-io/github-actions-centralization/issues/89)) ([38b952b](https://github.com/pleo-io/github-actions-centralization/commit/38b952bd1b6963e0576f3ed6069f8a2ec9433148))

## [5.0.3](https://github.com/pleo-io/github-actions-centralization/compare/v5.0.2...v5.0.3) (2021-05-17)


### Bug Fixes

* **gradle-workflows:** replace GH_REGISTRY_TOKEN with GH_REGISTRY_GRADLE_TOKEN ([#86](https://github.com/pleo-io/github-actions-centralization/issues/86)) ([166dda6](https://github.com/pleo-io/github-actions-centralization/commit/166dda6ee4b6744cb4a657a299c69971527c5c00))

## [5.0.2](https://github.com/pleo-io/github-actions-centralization/compare/v5.0.1...v5.0.2) (2021-05-13)


### Bug Fixes

* **stripe required:** Stripe API key is needed for Hydra ([#88](https://github.com/pleo-io/github-actions-centralization/issues/88)) ([5da4268](https://github.com/pleo-io/github-actions-centralization/commit/5da4268853a54f837db0ff490005e3920241dd86))

## [5.0.1](https://github.com/pleo-io/github-actions-centralization/compare/v5.0.0...v5.0.1) (2021-05-12)


### Bug Fixes

* **gh-workflows:** use gradle-sub-project instead of all-sub-projects ([#87](https://github.com/pleo-io/github-actions-centralization/issues/87)) ([8afb557](https://github.com/pleo-io/github-actions-centralization/commit/8afb557d97f1df9a4ac7a54f339dc1e8846f8036))

# [5.0.0](https://github.com/pleo-io/github-actions-centralization/compare/v4.0.0...v5.0.0) (2021-05-12)


* BREAKING CHANGE: Delete build_typescript and use npm-registry-token (#84) ([46a63f2](https://github.com/pleo-io/github-actions-centralization/commit/46a63f2f3804b5316ee1a79cc184e64d1b551bb9)), closes [#84](https://github.com/pleo-io/github-actions-centralization/issues/84)


### BREAKING CHANGES

* Delete build_typescript and use npm-registry-token

* Use NPM GH registry token

* Delete build TS file

# [4.0.0](https://github.com/pleo-io/github-actions-centralization/compare/v3.0.0...v4.0.0) (2021-05-11)


* BREAKING CHANGE: disable deployment part of build unless `deploymentEnabled` is true (#83) ([38920b0](https://github.com/pleo-io/github-actions-centralization/commit/38920b03d08567f5c7219b00af943e12f8bd0c5a)), closes [#83](https://github.com/pleo-io/github-actions-centralization/issues/83)


### BREAKING CHANGES

* disable deployment part of build workflow unless `deploymentEnabled` is true

# [3.0.0](https://github.com/pleo-io/github-actions-centralization/compare/v2.1.1...v3.0.0) (2021-05-06)


### Bug Fixes

* **dependabot:** update github actions folder for dependabot ([#82](https://github.com/pleo-io/github-actions-centralization/issues/82)) ([519fc34](https://github.com/pleo-io/github-actions-centralization/commit/519fc346bf93819262dcad51868ccf2c1fbf18d4))


### BREAKING CHANGES

* **dependabot:** change folder structure from templates/github/workflows to
templates/.github/workflows

## [2.1.1](https://github.com/pleo-io/github-actions-centralization/compare/v2.1.0...v2.1.1) (2021-05-05)


### Bug Fixes

* **build_typescript:** typo in the workflow ([#80](https://github.com/pleo-io/github-actions-centralization/issues/80)) ([a7f2f06](https://github.com/pleo-io/github-actions-centralization/commit/a7f2f064742055457e12d9f22db9bb9d52304095))

# [2.1.0](https://github.com/pleo-io/github-actions-centralization/compare/v2.0.4...v2.1.0) (2021-05-05)


### Features

* update publish_library_typescript.yaml to use deploy key for release ([#72](https://github.com/pleo-io/github-actions-centralization/issues/72)) ([1cbe8db](https://github.com/pleo-io/github-actions-centralization/commit/1cbe8dbfe5328fbb7209e4e109f5424981d97482))

## [2.0.4](https://github.com/pleo-io/github-actions-centralization/compare/v2.0.3...v2.0.4) (2021-05-05)


### Bug Fixes

* **gh workflows:** Snyk scan all subprojects ([c72cfd4](https://github.com/pleo-io/github-actions-centralization/commit/c72cfd495dad5e8c21f0af4e680deb90749a3f60))

## [2.0.3](https://github.com/pleo-io/github-actions-centralization/compare/v2.0.2...v2.0.3) (2021-05-04)


### Bug Fixes

* **gh workflows:** Skip configure AWS Production if not needed ([c61d653](https://github.com/pleo-io/github-actions-centralization/commit/c61d653ea3d2d06f93a956052a477c0d02c1af69))

## [2.0.2](https://github.com/pleo-io/github-actions-centralization/compare/v2.0.1...v2.0.2) (2021-05-04)


### Bug Fixes

* **gh workflows:** Skip Slack alert if no expected deployment to Production ([a21d900](https://github.com/pleo-io/github-actions-centralization/commit/a21d900c30601acc22731ca165fe0531da3ee397))

## [2.0.1](https://github.com/pleo-io/github-actions-centralization/compare/v2.0.0...v2.0.1) (2021-05-04)


### Bug Fixes

* **gh workflows:** Skip production-related steps when no production deploy is expected ([#75](https://github.com/pleo-io/github-actions-centralization/issues/75)) ([9f2e8a7](https://github.com/pleo-io/github-actions-centralization/commit/9f2e8a7098e58b1b3f1468c2288456cdc1d383df))

# [2.0.0](https://github.com/pleo-io/github-actions-centralization/compare/v1.1.0...v2.0.0) (2021-05-03)


### Code Refactoring

* **folder-structure:** remove symlink ([#73](https://github.com/pleo-io/github-actions-centralization/issues/73)) ([1666396](https://github.com/pleo-io/github-actions-centralization/commit/1666396a32faa8a7f094cdbc465b115f6b8a6f9d))


### BREAKING CHANGES

* **folder-structure:** removing old folders

# [1.1.0](https://github.com/pleo-io/github-actions-centralization/compare/v1.0.0...v1.1.0) (2021-05-03)


### Features

* **gh workflows:** deploy to prod optional ([#71](https://github.com/pleo-io/github-actions-centralization/issues/71)) ([7a75298](https://github.com/pleo-io/github-actions-centralization/commit/7a75298b71f5af0378ab5cc831b3375c840c1652))

# [1.0.0](https://github.com/pleo-io/github-actions-centralization/compare/v0.2.19...v1.0.0) (2021-05-03)


### Documentation

* **readme:** update with recent changes ([#67](https://github.com/pleo-io/github-actions-centralization/issues/67)) ([e8cf0d0](https://github.com/pleo-io/github-actions-centralization/commit/e8cf0d086a367afbe3a025ee1a499964c52981cc))


### BREAKING CHANGES

* **readme:** update folder structure

## [0.2.18](https://github.com/pleo-io/github-actions-centralization/compare/v0.2.17...v0.2.18) (2021-04-28)


### Bug Fixes

* **snyk:** update token name ([#66](https://github.com/pleo-io/github-actions-centralization/issues/66)) ([dcaf194](https://github.com/pleo-io/github-actions-centralization/commit/dcaf194c3e25d89fcbff35e8f5c5eced6317b419))

## [0.2.17](https://github.com/pleo-io/github-actions-centralization/compare/v0.2.16...v0.2.17) (2021-04-26)


### Bug Fixes

* **pencil:** make coveralls publish CI step optional ([f0627d2](https://github.com/pleo-io/github-actions-centralization/commit/f0627d22f7f0aa4b5b1ec7c4baa44774c9f7dfa8))

## [0.2.16](https://github.com/pleo-io/github-actions-centralization/compare/v0.2.15...v0.2.16) (2021-04-20)


### Bug Fixes

* **deps:** bump styfle/cancel-workflow-action in /devops_workflows ([#64](https://github.com/pleo-io/github-actions-centralization/issues/64)) ([d4053c0](https://github.com/pleo-io/github-actions-centralization/commit/d4053c01c09e28332ca460d8995f9b1e88d222cc))

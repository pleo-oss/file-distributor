## Intent

Linear story: [XXX-XXX](https://linear.app/pleo/issue/XXX-XXX)

<!-- Otherwise, what is the intent of this PR? -->

Link to any associated PRs resulting from changes in this PR:
-

## Potential Issues and Requests From Reviewers


### Have you
- [ ] Added a new logical variable to a workflow?
- [ ] Created a sensible default value for this value? 
- [ ] Added the variable to the list of optional values for new moons in the `README`?
